# Job-management

This project contains APIs for the Mobile APP and it also contains Web

## Dependencies

1. Python 3.8

## Setup

1. Clone the project.
```sh
git clone git@github.com:priteshtagline/job-management.git
cd job-management/
```

2. Create a virtual env and activate it.

```sh
python3 -m venv env
source env/bin/activate
```

3. Install requirements.txt file with this command.

```sh
pip install -r requirements.txt
```

4. Copy the .env.example into .env file.

```sh
cp .env.example .env
```

5. Load the user roles

```sh
python manage.py loaddata roles.json
```

6. Create Superuser

```sh
python manage.py createsuperuser
```

7. Run the local server

```sh
python manage.py runserver
```
