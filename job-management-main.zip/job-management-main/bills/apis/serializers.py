from rest_framework import serializers

from users.models.bill import Bill


class BillSerializers(serializers.ModelSerializer):
    created_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    updated_by = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = Bill
        fields = "__all__"


class BillUpdateSerializers(serializers.ModelSerializer):
    updated_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    type_counting = serializers.CharField(required=False)
    name = serializers.CharField(required=False)

    class Meta:
        model = Bill
        exclude = ["created_by"]

    def update(self, instance, validated_data):
        instance = super().update(instance, validated_data)
        instance.updated_by = self.context["request"].user
        instance.save()
        return instance
