from django.urls import include
from django.urls import path
from rest_framework.routers import DefaultRouter

from bills.apis.views import BillView

router = DefaultRouter()
router.register("", BillView, basename="session_auth")


urlpatterns = [
    path("", include(router.urls)),
]
