from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import filters
from rest_framework import status
from rest_framework import viewsets
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response

from bills.apis.serializers import BillSerializers
from bills.apis.serializers import BillUpdateSerializers
from users.models.bill import Bill


class BillView(viewsets.ModelViewSet):
    queryset = Bill.objects.exclude(is_close_time_created=True)
    serializer_class = BillSerializers
    parser_classes = [MultiPartParser]
    filter_backends = [filters.SearchFilter]
    search_fields = ["name"]

    view_permissions = {
        "list": {"admin": True, "inspector": True, "group_manger": True},
        "retrieve": {"admin": True, "inspector": True, "group_manger": True},
        "create": {"admin": True, "group_manger": True},
        "destroy": {"admin": True},
        "partial_update": {"admin": True},
    }

    def get_serializer_class(self):
        if self.request.method == "PATCH":
            serializer = BillUpdateSerializers
            return serializer
        else:
            return self.serializer_class

    type = openapi.Parameter(
        "bill_type",
        openapi.IN_QUERY,
        required=False,
        description="Bill Type should be Material or Sign",
        type=openapi.TYPE_STRING,
    )

    @swagger_auto_schema(manual_parameters=[type])
    def list(self, request, *args, **kwargs):
        bill_type = self.request.query_params.get("bill_type", None)
        if bill_type:
            queryset = self.paginate_queryset(
                self.filter_queryset(self.queryset.filter(type=bill_type)).order_by(
                    "-created_at"
                )
            )
        else:
            queryset = self.paginate_queryset(
                self.filter_queryset(self.queryset).order_by("-created_at")
            )
        serializer = self.serializer_class(
            queryset, many=True, context={"request": request}
        )
        return self.get_paginated_response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        # "detail": "Bill deleted successfully"
        return Response({"detail": "סעיף נמחק בהצלחה"}, status=status.HTTP_202_ACCEPTED)

    def partial_update(self, request, *args, **kwargs):
        kwargs["partial"] = True
        if self.get_queryset().filter(name=request.data.get("name")).exists():
            # "detail": "bill with this Bill Name already exists."
            return Response(
                {"detail": "כבר קיים סעיף עם שם זה"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        else:
            return self.update(request, *args, **kwargs)
