from django import forms

from users.models.bill import Bill
from users.models.job import CloseJobBill


class BillForm(forms.ModelForm):
    class Meta:
        model = Bill
        fields = [
            "name",
            "image",
            "type_counting",
            "jumping_ration",
            "type",
            "is_close_time_created",
        ]



class CloseBillForm(forms.ModelForm):
    class Meta:
        model = CloseJobBill
        fields = [
            "name",
            "image",
            "type_counting",
            "jumping_ration",
            "type",
            "job",
            "is_created",
        ]

    def save(self):
        bill = super(CloseBillForm, self).save(commit=True)
        if "image" in self.cleaned_data:
            image = self.cleaned_data.pop("image")
            bill.image = image
            bill.save()
        return bill
