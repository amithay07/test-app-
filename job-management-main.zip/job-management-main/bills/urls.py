from django.urls import path

from bills.views import BillCreateView
from bills.views import BillDeleteView
from bills.views import BillListView
from bills.views import BillUpdateView

app_name = "bills"
urlpatterns = [
    path("<str:bill_type>/", BillListView.as_view(), name="bill-list"),
    path("bill-create/<str:bill_type>/", BillCreateView.as_view(), name="bill-create"),
    path(
        "bill-update/<int:pk>/",
        BillUpdateView.as_view(),
        name="bill-update",
    ),
    path(
        "bill-delete/<str:bill_type>/<int:pk>/",
        BillDeleteView.as_view(),
        name="bill-delete",
    ),
]
