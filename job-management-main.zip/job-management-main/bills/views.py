from django.contrib.auth.decorators import login_required
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger
from django.core.paginator import Paginator
from django.http import HttpResponseRedirect
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.urls import reverse
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.generic import CreateView
from django.views.generic import DeleteView
from django.views.generic import ListView
from django.views.generic import UpdateView

from bills.forms import BillForm
from jobs.views import NotificationList
from users.models.bill import Bill
from users.models.bill import BillType
from users.models.bill import TypeCounting
from users.permission import OnlyForAdmin
from users.utils import get_query_params


@method_decorator(login_required, name="dispatch")
class BillListView(ListView):
    model = Bill
    template_name = "bill.html"
    success_url = reverse_lazy("bills:bill-list")
    form_class = BillForm
    queryset = Bill.objects.all()
    paginate_by = 10
    ordering = ["-created_at"]

    def get_queryset(self):
        search = self.request.GET.get("search")
        if search:
            return super().get_queryset().filter(name__icontains=search)
        return super().get_queryset()

    def get_context_data(self, **kwargs):
        queryset = self.object_list
        (from_date, to_date) = get_query_params(self.request.GET)
        page_number = self.request.GET.get("page")
        bill_type = self.request.path.split("/")[-2:-1][0]

        bill_value = (
            BillType.SIGN.value if bill_type == "Sign" else BillType.MATERIAL.value
        )

        bills_list = (
            queryset.filter(
                type=bill_value,
                created_at__date__range=[from_date, to_date],
            )
            if from_date and to_date
            else queryset.filter(type=bill_value)
        )

        paginator = Paginator(bills_list, 10)
        bills_list = paginator.get_page(page_number)

        try:
            page_range = paginator.page(page_number)
        except PageNotAnInteger:
            page_range = paginator.page(1)
        except EmptyPage:
            page_range = paginator.page(paginator.num_pages)
        context = super().get_context_data(
            **kwargs,
            type_counting_list=[val for key, val in TypeCounting.choices],
            type_list=[val for key, val in BillType.choices],
            bills_list=bills_list,
            paginator=paginator,
            page_range=page_range,
            bill_type=bill_type,
            from_date=from_date,
            to_date=to_date,
            notification=NotificationList(self)
        )
        return context


@method_decorator(login_required, name="dispatch")
class BillCreateView(CreateView):
    model = Bill
    template_name = "bill.html"
    form_class = BillForm
    success_url = reverse_lazy("bills:bill-list")

    def post(self, request, *args, **kwargs):
        form = self.form_class(self.request.POST, self.request.FILES)
        if form.is_valid():
            user = self.request.user
            form.instance.created_by = user
            form.instance.updated_by = user
            form.save()
            return JsonResponse({"create_bill_status": "success"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class BillDeleteView(DeleteView):
    model = Bill
    template_name = "bill_delete.html"
    queryset = Bill.objects.all()

    def form_valid(self, form):
        bill_type = self.request.path.split("/")[-3:-2][0]
        self.object.delete()
        return HttpResponseRedirect(reverse("bills:bill-list", args=(bill_type,)))


@method_decorator(login_required, name="dispatch")
class BillUpdateView(OnlyForAdmin, UpdateView):
    model = Bill
    template_name = "bill.html"
    form_class = BillForm
    success_url = reverse_lazy("bills:bill-list")
    queryset = Bill.objects.all()

    def get(self, request, pk, *args, **kwargs):
        bill_data = list(Bill.objects.filter(id=pk).values())
        return JsonResponse({"form": bill_data})

    def post(self, request, *args, **kwargs):
        bill_obj = get_object_or_404(Bill, id=kwargs.get("pk"))
        form = self.form_class(
            instance=bill_obj, data=self.request.POST, files=request.FILES
        )
        if form.is_valid():
            form.save()
            return JsonResponse({"bill_update_status": True})
        return JsonResponse({"error": form.errors if form.errors else None})
