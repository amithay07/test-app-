import base64
import json

import jwt
from channels.db import database_sync_to_async
from channels.exceptions import StopConsumer
from channels.generic.websocket import AsyncWebsocketConsumer
from django.conf import settings
from django.contrib.sessions.backends.db import SessionStore
from django.core.files.base import ContentFile
from django.db.models import F

from chat.apis.serializers import MessageSerializer
from chat.models import Chat
from chat.models import Message
from chat.models import TempChatAttestment
from chat.models import UnreadMessage
from jobs.utils import push_notification
from users.models.job import TransferJob
from users.models.notification import ChatNotification
from users.models.user import User


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.chat_id = self.scope["url_route"]["kwargs"]["chat_id"]
        self.room_group_name = f"JM_{self.chat_id}"
        user_token = self.scope["url_route"]["kwargs"]["token"]
        if len(user_token) == 32:
            try:
                user_id = await database_sync_to_async(self.get_user_from_session)(
                    user_token
                )
            except:
                raise StopConsumer()
        else:
            try:
                decodedPayload = jwt.decode(
                    user_token,
                    settings.SECRET_KEY,
                    algorithms=["HS256"],
                )
                user_id = decodedPayload.get("user_id")
            except:
                raise StopConsumer()
        self.user = await database_sync_to_async(self.get_user)(user_id)
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()
        await database_sync_to_async(self.set_online_room)()

    async def receive(self, text_data):
        message = await database_sync_to_async(self.save_chat)(text_data)
        text_data = json.loads(text_data)
        if message["sender"]["profile_image"]:
            message["sender"][
                "profile_image"
            ] = f"{message['sender']['profile_image']}"

        # if message.get("attestment"):
        #     message["attestment"] = f"{message['attestment']}"

        await database_sync_to_async(self.send_chat_notification)(message)
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                "type": "chat_message",
                "message": json.dumps(message),
            },
        )

    async def disconnect(self, close_code):
        await database_sync_to_async(self.set_offline_room)()
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def chat_message(self, event):
        message = event["message"]
        await self.send(message)

    def get_user(self, user_id):
        return User.objects.get(id=user_id)

    def save_chat(self, message):
        text_data = json.loads(message)
        metadata = {}
        if text_data.get("temp_image_id"):
            file_content = TempChatAttestment.objects.get(
                id=text_data.get("temp_image_id")
            )
            metadata["extensions"] = (file_content.temp_media_file.url).split(".").pop()

        metadata["job_id"] = (
            text_data.get("job_id") if text_data.get("job_id") else None
        )
        body = text_data["body"]
        if text_data.get("attestment"):
            extensions = text_data["extensions"]
            attestment_obj = ContentFile(
                base64.b64decode(text_data["attestment"]),
                name=text_data["file_name"] + "." + extensions,
            )
            metadata["extensions"] = (
                text_data.get("extensions") if text_data.get("extensions") else None
            )
        else:
            attestment_obj = None

        if text_data.get("job_id"):
            job = TransferJob.objects.prefetch_related("job__job_image").get(id=text_data.get("job_id"))
            job_image = job.job.job_image if job.job.job_image.first() else None
            message = Message.objects.create(
                chat_id=self.chat_id,
                body=body,
                sender=self.user,
                attestment=attestment_obj,
                metadata=metadata,
                job_address=job.job.address,
                job_description=job.job.description,
            )
            if job_image:
                message.job_image.save(
                    job_image.image.name.replace("chat_job/", ""), job_image.image
                )
        else:
            message = Message.objects.create(
                chat_id=self.chat_id,
                body=body,
                sender=self.user,
                attestment=attestment_obj,
                metadata=metadata,
            )

        if text_data.get("temp_image_id"):
            message.attestment.save(
                file_content.temp_media_file.name.replace("temp_chat_attestment/", ""),
                file_content.temp_media_file,
            )
            message.save()
            TempChatAttestment.objects.get(id=text_data.get("temp_image_id")).delete()

        group = Chat.objects.get(id=self.chat_id).group

        # chat_member = []
        # all_admin = (
        #     User.objects.filter(
        #         role__title=UserRoleChoices.ADMIN.value,
        #     )
        #     .exclude(is_deleted=True)
        #     .values_list("id", flat=True)
        # )

        # chat_member = list(all_admin) + list(group.member.values_list("id", flat=True))

        # group_user_list = list(set(chat_member))
        group_user_list = list(group.member.values_list("id", flat=True))

        online_user = UnreadMessage.objects.filter(
            member__in=group_user_list, chat_id=self.chat_id, is_online=True
        ).values_list("member", flat=True)

        group_user_list.remove(
            self.user.id
        ) if self.user.id in group_user_list else None

        group_user_list = set(group_user_list) - set(online_user)

        unread_message_member = UnreadMessage.objects.filter(
            member__in=group_user_list, chat_id=self.chat_id
        ).exclude(member__in=online_user)

        unread_message_member_list = unread_message_member.values_list(
            "member", flat=True
        )

        unread_message_member.update(unread_message_count=F("unread_message_count") + 1)

        unread_message_list = []
        new_member_list = set(group_user_list) - set(unread_message_member_list)

        for new_member in new_member_list:
            unread_message_list.append(
                UnreadMessage(
                    member_id=new_member, chat_id=self.chat_id, unread_message_count=1
                )
            )

        UnreadMessage.objects.bulk_create(unread_message_list)
        return MessageSerializer(message).data

    def set_online_room(self):
        try:
            user_message = UnreadMessage.objects.filter(
                chat=self.chat_id, member=self.user
            ).first()

            if user_message:
                user_message.is_online = True
                user_message.unread_message_count = 0
                user_message.connected_count = user_message.connected_count + 1
                user_message.save()
            else:
                UnreadMessage.objects.create(
                    chat_id=self.chat_id,
                    member=self.user,
                    is_online=True,
                    connected_count=1,
                )
        except:
            raise StopConsumer()

    def set_offline_room(self):
        user_message = UnreadMessage.objects.filter(
            chat_id=self.chat_id, member=self.user
        ).first()

        if user_message.connected_count != 1:
            user_message.connected_count -= 1
            UnreadMessage.objects.filter(chat_id=self.chat_id, member=self.user).update(
                connected_count=user_message.connected_count
            )
        else:
            UnreadMessage.objects.filter(chat_id=self.chat_id, member=self.user).update(
                is_online=False, connected_count=0
            )

    def send_chat_notification(self, message):
        chat_obj = Chat.objects.get(id=self.chat_id)
        offline_member_id = chat_obj.unread_messages.filter(
            is_online=False
        ).values_list("member", flat=True)

        message["notification_type"] = "chat"
        message["group_name"] = chat_obj.group.name
        push_notification(
            user=offline_member_id,
            notification_data=message,
        )

        sender = message["sender"]["id"]
        bulk_notification = []
        notification_count = []

        for receiver in offline_member_id:
            bulk_notification.append(
                ChatNotification(
                    message=(message["body"]).strip(),
                    attachment=message["attestment"],
                    notification_type="chat",
                    group_id=message["chat"],
                    receiver_id=receiver,
                    sender_id=sender,
                    created_by_id=sender,
                    updated_by_id=sender,
                )
            )

            notification_count.append(
                ChatNotification.objects.filter(receiver_id=receiver)
                .order_by("-created_at")[20:]
                .values_list("id", flat=True)
            )

        ChatNotification.objects.filter(id__in=notification_count).delete()
        ChatNotification.objects.bulk_create(bulk_notification)

    def get_user_from_session(self, token):
        session = SessionStore(session_key=token)
        user_id = session.get("_auth_user_id")
        return user_id
