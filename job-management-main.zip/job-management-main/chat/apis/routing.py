from django.urls import path

from .consumers import ChatConsumer

# URLs that handle the WebSocket connection are placed here.
websocket_urlpatterns = [
    path("ws/chat/<int:chat_id>/<str:token>/", ChatConsumer.as_asgi()),
]
