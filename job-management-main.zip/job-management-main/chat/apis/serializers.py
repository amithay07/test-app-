import os

import requests
from django.conf import settings
from rest_framework import serializers

from chat.models import Chat
from chat.models import Message
from users.models.group import Group
from users.models.user import User


class ChatGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ("id", "name", "image")


class SenderSerializers(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            "id",
            "profile_image",
            "user_name",
        )


class ChatSerializer(serializers.ModelSerializer):
    group = ChatGroupSerializer()
    message = serializers.CharField()
    unread_message_count = serializers.IntegerField()

    class Meta:
        model = Chat
        exclude = ("updated_at", "updated_by")


class MessageSerializer(serializers.ModelSerializer):
    sender = SenderSerializers()
    attestment = serializers.SerializerMethodField()

    class Meta:
        model = Message
        fields = (
            "id",
            "chat",
            "body",
            "sender",
            "attestment",
            "metadata",
            "created_at",
            "job_address",
            "job_description",
            "job_image",
        )

    def get_attestment(self, obj):
        attachment_url = str(obj.attestment)
        if int(os.environ["USE_S3"]):
            s3_url = settings.MEDIA_URL + attachment_url
            response = requests.head(s3_url)
            content_length = response.headers.get("content-length")

            modified_attachment = {
                "file_name": attachment_url.split("/")[-1],
                "url": s3_url,
                "size": content_length,
            }

        else:
            url = os.environ["SERVER_URL"] + settings.MEDIA_URL + attachment_url
            response = requests.head(url)
            content_length = response.headers.get("content-length")
            modified_attachment = {
                "file_name": attachment_url.split("/")[-1],
                "url": url,
                "size": content_length,
            }

        if modified_attachment:
            return modified_attachment
        return None
