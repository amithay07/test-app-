from django.urls import path

from .views import ArchiveChatListView
from .views import ArchiveMessageListView
from .views import ChatListView
from .views import MessageListView

urlpatterns = [
    path("", ChatListView.as_view(), name="chat_list"),
    path("<int:chat_id>/", MessageListView.as_view(), name="message_list"),
    path("archive/", ArchiveChatListView.as_view(), name="archive_chat_list"),
    path(
        "archive/<int:chat_id>/",
        ArchiveMessageListView.as_view(),
        name="archive_chat_message_list",
    ),
]
