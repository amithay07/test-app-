from django.db.models import Max
from django.db.models import OuterRef
from django.db.models import Subquery
from rest_framework import filters
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated

from chat.apis.serializers import ChatSerializer
from chat.apis.serializers import MessageSerializer
from chat.models import Chat
from chat.models import Message
from chat.models import UnreadMessage

class ChatListView(ListAPIView):
    queryset = Chat.objects.exclude(group__is_archive=True)
    serializer_class = ChatSerializer
    filter_backends = [filters.SearchFilter]
    permission_classes = [IsAuthenticated]
    search_fields = ["group__name", "message"]

    def get_queryset(self):
        user = self.request.user
        query_set = super().get_queryset()
        if not user.is_superuser:
            query_set = query_set.filter(group__member__in=[user])

        return query_set.annotate(
            unread_message_count=Subquery(
                UnreadMessage.objects.filter(member=user, chat=OuterRef("id")).values(
                    "unread_message_count"
                )[:1]
            ),
            last_message_time=Max("messages__created_at"),
            message=Subquery(
                Message.objects.filter(chat=OuterRef("id"))
                .order_by("-created_at")
                .values("body")[:1]
            ),
        ).order_by("-last_message_time")


class MessageListView(ListAPIView):
    queryset = Message.objects.exclude(chat__group__is_archive=True)
    serializer_class = MessageSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .filter(chat_id=self.kwargs["chat_id"])
            .order_by("-created_at")
        )


class ArchiveChatListView(ListAPIView):
    queryset = Chat.objects.exclude(group__is_archive=False)
    serializer_class = ChatSerializer
    filter_backends = [filters.SearchFilter]
    permission_classes = [IsAuthenticated]
    search_fields = ["group__name", "message"]

    def get_queryset(self):
        user = self.request.user
        query_set = super().get_queryset()
        if not user.is_superuser:
            query_set = query_set.filter(group__member__in=[user])

        return query_set.annotate(
            unread_message_count=Subquery(
                UnreadMessage.objects.filter(member=user, chat=OuterRef("id")).values(
                    "unread_message_count"
                )[:1]
            ),
            last_message_time=Max("messages__created_at"),
            message=Subquery(
                Message.objects.filter(chat=OuterRef("id"))
                .order_by("-created_at")
                .values("body")[:1]
            ),
        ).order_by("-last_message_time")


class ArchiveMessageListView(ListAPIView):
    queryset = Message.objects.all()
    serializer_class = MessageSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .filter(chat_id=self.kwargs["chat_id"])
            .order_by("-created_at")
            .exclude(chat__group__is_archive=False)
        )
