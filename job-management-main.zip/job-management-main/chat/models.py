from django.db import models
from django.utils.translation import gettext_lazy as _

from job.base_model_utils import BaseModel
from users.models.group import Group
from users.models.user import User
from users.utils import get_chat_path


class Chat(BaseModel):
    group = models.ForeignKey(
        Group,
        on_delete=models.CASCADE,
        related_name="chats",
    )

    class Meta:
        db_table = "chat"
        verbose_name = "chat"
        verbose_name_plural = "chats"


class UnreadMessage(BaseModel):
    chat = models.ForeignKey(
        Chat, related_name="unread_messages", on_delete=models.CASCADE
    )
    member = models.ForeignKey(
        User, related_name="unread_messages", on_delete=models.CASCADE
    )
    unread_message_count = models.IntegerField(default=0)
    is_online = models.BooleanField(default=False)
    connected_count = models.IntegerField(default=0)

    class Meta:
        db_table = "chats_unread_message"
        verbose_name = "chats_unread_message"
        verbose_name_plural = "chats_unread_messages"


class Message(BaseModel):
    chat = models.ForeignKey(
        Chat, on_delete=models.CASCADE, related_name="messages", db_index=True
    )
    body = models.TextField()
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sender")
    attestment = models.FileField(upload_to=get_chat_path, null=True, blank=True)
    metadata = models.JSONField(null=True, blank=True)
    job_address = models.CharField(_("address"), max_length=255, null=True)
    job_description = models.CharField(_("job description"), max_length=255, null=True)
    job_image = models.FileField(upload_to=get_chat_path, null=True, blank=True)

    class Meta:
        db_table = "message"
        verbose_name = "message"
        verbose_name_plural = "messages"


class TempChatAttestment(models.Model):
    temp_media_file = models.FileField(
        upload_to="temp_chat_attestment/", null=True, blank=True
    )
