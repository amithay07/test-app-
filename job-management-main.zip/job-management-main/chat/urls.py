from django.urls import path

from chat.views import ChatListView
from chat.views import MessageListView
from chat.views import upload_chat_audio
from chat.views import upload_chat_image

app_name = "chats"
urlpatterns = [
    path("", ChatListView.as_view(), name="chat-list"),
    path("<int:chat_id>", MessageListView.as_view(), name="message-list"),
    path("upload-image", upload_chat_image, name="upload_file"),
    path("upload-audio", upload_chat_audio, name="upload_audio"),
]
