import json
import re

from django.contrib.auth.decorators import login_required
from django.core.serializers.json import DjangoJSONEncoder
from django.db.models import F
from django.db.models import Max
from django.db.models import OuterRef
from django.db.models import Subquery
from django.http import HttpResponse
from django.http import HttpResponseNotAllowed
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import ListView

from chat.models import Chat
from chat.models import Message
from chat.models import TempChatAttestment
from chat.models import UnreadMessage
from jobs.views import NotificationList
from users.models.group import Group


@method_decorator(login_required, name="dispatch")
class ChatListView(ListView):
    model = Chat
    template_name = "chat.html"
    success_url = reverse_lazy("chats:chat-list")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        query_set = Chat.objects.exclude(group__is_archive=True).select_related("group")
        if not user.is_superuser:
            query_set = query_set.filter(group__member__in=[user])

        chat_contacts = query_set.annotate(
            unread_message_count=Subquery(
                UnreadMessage.objects.filter(member=user, chat=OuterRef("id")).values(
                    "unread_message_count"
                )[:1]
            ),
            last_message_time=Max("messages__created_at"),
            message=Subquery(
                Message.objects.filter(chat=OuterRef("id"))
                .order_by("-created_at")
                .values("body")[:1]
            ),
            metadata=Subquery(
                Message.objects.filter(chat=OuterRef("id"))
                .order_by("-created_at")
                .values("metadata")[:1]
            ),
        ).order_by("-last_message_time")

        context["notification"] = NotificationList(self)
        context["chat_contacts_list"] = chat_contacts
        context["group_list"] = (
            Group.objects.filter(member=user.id).exclude(is_archive=True)
            if not user.is_superuser
            else Group.objects.exclude(is_archive=True)
            if user.is_superuser
            else None
        )
        return context

    def get(self, request, *args, **kwargs):
        user = request.user
        query_set = None
        group_search = request.GET.get("group_search")
        if group_search == "":
            query_set = Chat.objects.exclude(group__is_archive=True).select_related(
                "group"
            )
        elif group_search:
            query_set = (
                Chat.objects.filter(group__name__contains=group_search)
                .exclude(group__is_archive=True)
                .select_related("group")
            )
        if query_set:
            if not self.request.user.is_superuser:
                query_set = query_set.filter(group__member__in=[user])

            query_set = (
                query_set.annotate(
                    unread_message_count=Subquery(
                        UnreadMessage.objects.filter(
                            member=user, chat=OuterRef("id")
                        ).values("unread_message_count")[:1]
                    ),
                    last_message_time=Max("messages__created_at"),
                    message=Subquery(
                        Message.objects.filter(chat=OuterRef("id"))
                        .order_by("-created_at")
                        .values("body")[:1]
                    ),
                )
                .order_by("-last_message_time")
                .values(
                    "group_id",
                    "group__image",
                    "group__name",
                    "message",
                    "last_message_time",
                    "unread_message_count",
                )
            )
            return JsonResponse({"groups": list(query_set)})
        return super().get(request, *args, **kwargs)


class MessageListView(ListView):
    queryset = Message.objects.exclude(chat__group__is_archive=True)

    def get(self, request, *args, **kwargs):
        message = json.dumps(
            list(
                self.queryset.filter(chat_id=self.kwargs["chat_id"])
                .annotate(
                    sender_img=F("sender__profile_image"),
                    sender_name=F("sender__user_name"),
                    sender_email=F("sender__email"),
                )
                .values()
            ),
            cls=DjangoJSONEncoder,
        )
        group = json.dumps(
            Chat.objects.filter(id=self.kwargs["chat_id"]).values(
                "group__id",
                "group__image",
                "group__name",
                "group__member__group_member",
            )[0],
            cls=DjangoJSONEncoder,
        )

        group_member = (
            (Group.objects.get(id=re.split(":|,", group)[1]))
            .member.all()
            .exclude(user_name__isnull=True)
            .values_list("user_name", flat=True)
        )

        return JsonResponse(
            {
                "message_list": message,
                "group": group,
                "group_member": str(", ".join(group_member)),
            }
        )


@csrf_exempt
def upload_chat_image(request):
    if request.method == "POST":
        uploaded_file = request.FILES["file"]
        file_ext = uploaded_file.name.split(".")[-1]
        file_size = round(uploaded_file.size / (1024 * 1024), 2)
        mymodel = TempChatAttestment()
        mymodel.temp_media_file.save(uploaded_file.name, uploaded_file)
        response = {
            "id": mymodel.id,
            "url": mymodel.temp_media_file.url,
            "file_size": f"{file_size} MB",
            "file_ext": file_ext,
        }
        return JsonResponse(response)
    elif request.method == "DELETE":
        obj = get_object_or_404(TempChatAttestment, id=request.GET["id"])
        obj.delete()
        return HttpResponse(status=204)
    else:
        return HttpResponseNotAllowed(["DELETE", "POST"])


@csrf_exempt
def upload_chat_audio(request):
    uploaded_file = request.FILES["audio"]
    mymodel = TempChatAttestment()
    mymodel.temp_media_file.save(uploaded_file.name, uploaded_file)
    response = {
        "id": mymodel.id,
        "url": mymodel.temp_media_file.url,
    }
    return JsonResponse(response)
