from rest_framework import serializers

from bills.apis.serializers import BillSerializers
from users.models.bill import Bill
from users.models.bill import BillType
from users.models.form import Form


class FormSerializer(serializers.ModelSerializer):
    created_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    updated_by = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = Form
        read_only_fields = ["id"]
        fields = "__all__"

    def create(self, validated_data):
        is_sign = validated_data.get("is_sign")
        bill_data = validated_data.get("bill")
        bills = Bill.objects.filter(
            type=BillType.SIGN.value, is_close_time_created=False
        ).values_list("id", flat=True)
        instance = super().create(validated_data)
        if is_sign and bill_data:
            for bill in bills:
                instance.bill.add(bill)
                instance.save()
        elif is_sign:
            for bill in bills:
                instance.bill.add(bill)
                instance.save()
        return instance

    def to_representation(self, instance):
        represent = super().to_representation(instance)
        represent["bill"] = BillSerializers(
            instance.bill.all(), many=True, context=self.context
        ).data
        return represent

    def update(self, instance, validated_data):
        bill_data = validated_data.get('bill')
        instance.bill.clear()
        instance = super().update(instance, validated_data)
        if "is_sign" in validated_data:
            is_sign = validated_data.get("is_sign")
            bills = Bill.objects.filter(
                type=BillType.SIGN.value, is_close_time_created=False
            ).values_list("id", flat=True)
            if is_sign:
                for bill in bills:
                    instance.bill.add(bill)
                    instance.is_sign = True
                    instance.save()
            else:
                for bill in bills:
                    instance.bill.remove(bill)
                    instance.is_sign = False
                    instance.save()
        if bill_data:
            for bill in bill_data:
                instance.bill.add(bill)
                instance.save()
        instance.updated_by = self.context["request"].user
        instance.save()
        return instance
