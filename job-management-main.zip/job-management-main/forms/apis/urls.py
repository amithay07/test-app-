from django.urls import include
from django.urls import path
from rest_framework.routers import DefaultRouter

from forms.apis.views import FromView

router = DefaultRouter()
router.register("", FromView, basename="session_auth")


urlpatterns = [
    path("", include(router.urls)),
]
