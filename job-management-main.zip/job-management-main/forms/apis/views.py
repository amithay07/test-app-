from rest_framework import filters
from rest_framework import status
from rest_framework import viewsets
from rest_framework.response import Response

from forms.apis.serializers import FormSerializer
from users.models.form import Form


class FromView(viewsets.ModelViewSet):
    queryset = Form.objects.order_by("-created_at")
    serializer_class = FormSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["name"]
    view_permissions = {
        "list": {"admin": True, "inspector": True, "group_manger": True},
        "retrieve": {"admin": True, "inspector": True, "group_manger": True},
        "create": {"admin": True},
        "destroy": {"admin": True},
        "partial_update": {"admin": True},
    }

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(
            data=request.data,
            context={"request": request, "is_sign": request.data["is_sign"]},
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        # {"detail": "Form deleted successfully"}
        return Response({"detail": "טופס נמחק בהצלחה"}, status=status.HTTP_202_ACCEPTED)
