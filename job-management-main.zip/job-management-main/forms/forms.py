from django import forms

from users.models.form import Form


class FormModleForm(forms.ModelForm):
    class Meta:
        model = Form
        fields = "__all__"
