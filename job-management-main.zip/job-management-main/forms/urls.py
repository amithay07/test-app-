from django.urls import path

from forms.views import FormCreateView
from forms.views import FormDeleteView
from forms.views import FormListView
from forms.views import FormUpdateView

app_name = "forms"
urlpatterns = [
    path("", FormListView.as_view(), name="form-list"),
    path("form-add/", FormCreateView.as_view(), name="form-add"),
    path("form-update/<int:pk>/", FormUpdateView.as_view(), name="form-update"),
    path("form-delete/<int:pk>/", FormDeleteView.as_view(), name="form-delete"),
]
