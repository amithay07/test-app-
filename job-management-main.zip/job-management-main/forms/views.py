from django.contrib.auth.decorators import login_required
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.generic import CreateView
from django.views.generic import DeleteView
from django.views.generic import ListView
from django.views.generic import UpdateView

from forms.forms import FormModleForm
from jobs.views import NotificationList
from users.models.bill import Bill
from users.models.bill import BillType
from users.models.form import Form
from users.utils import get_query_params


@method_decorator(login_required, name="dispatch")
class FormListView(ListView):
    model = Form
    form_class = FormModleForm
    template_name = "form.html"
    success_url = reverse_lazy("forms:form-list")
    ordering = ["-created_at"]

    def get_queryset(self):
        search = self.request.GET.get("search")
        if search:
            return super().get_queryset().filter(name__icontains=search)
        return super().get_queryset()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        queryset = self.object_list
        (from_date, to_date) = get_query_params(self.request.GET)
        page_number = self.request.GET.get("page")

        forms_list = (
            queryset.filter(created_at__date__range=[from_date, to_date])
            if from_date and to_date
            else queryset
        )

        paginator = Paginator(forms_list, 10)
        context["paginator"] = paginator
        context["forms_list"] = paginator.get_page(page_number)
        try:
            context["page_range"] = paginator.page(page_number)
        except PageNotAnInteger:
            context["page_range"] = paginator.page(1)
        except EmptyPage:
            context["page_range"] = paginator.page(paginator.num_pages)

        context["bill_list"] = Bill.objects.order_by("-created_at").exclude(
            type=BillType.SIGN.value
        )
        context["from_date"] = from_date
        context["to_date"] = to_date
        context["notification"] = NotificationList(self)
        return context


@method_decorator(login_required, name="dispatch")
class FormCreateView(CreateView):
    model = Form
    form_class = FormModleForm
    template_name = "form.html"
    success_url = reverse_lazy("forms:form-list")

    def post(self, request, *args, **kwargs):
        data = normalize_post_data(request)
        form = self.form_class(data)
        if form.is_valid():
            form.instance.created_by = request.user
            form.instance.updated_by = request.user
            form = form.save()
            if data["is_sign"]:
                form.bill.add(*list(Bill.objects.filter(type=BillType.SIGN)))
            super(FormCreateView, self).post(request, *args, **kwargs)
            return JsonResponse({"create_form_status": "success"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class FormUpdateView(UpdateView):
    model = Form
    form_class = FormModleForm
    template_name = "form.html"
    success_url = reverse_lazy("forms:form-list")

    def get(self, request, *args, **kwargs):
        pk = kwargs.get("pk")
        instance = self.model.objects.filter(id=pk)
        response = list(instance.values())
        bills = getattr(instance.first(), "bill").values()
        material_bills = list(bills.filter(type=BillType.MATERIAL))
        return JsonResponse({"data": response, "bills": material_bills})

    def post(self, request, *args, **kwargs):
        data = normalize_post_data(request)
        form = get_object_or_404(Form, id=kwargs.get("pk"))
        form = self.form_class(instance=form, data=data)
        if form.is_valid():
            form.save()
            return JsonResponse({"update_form_status": "success"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class FormDeleteView(DeleteView):
    model = Form
    template_name = "form_delete.html"
    success_url = reverse_lazy("forms:form-list")
    queryset = Form.objects.all()


def normalize_post_data(request):
    data = {
        key: value if key == "name" else request.POST.getlist(key)
        for key, value in request.POST.items()
    }
    data["is_sign"] = (
        True
        if (data.get("bill").pop(0) if "is_sign" in data.get("bill") else False)
        else False
    )
    return data
