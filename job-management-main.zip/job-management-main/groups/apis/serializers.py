from drf_extra_fields.fields import ImageField
from rest_framework import serializers

from forms.apis.serializers import FormSerializer
from jobs.apis.serializers import GetJobCreateSerializer
from jobs.apis.serializers import GetTransferJobSerializers
from users.apis import serializers as User_serializers
from users.models.form import Form
from users.models.group import Group
from users.models.job import Job
from users.models.job import JobStatus
from users.models.job import TransferJob


class PermissionGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ["id", "name", "image"]


class GroupSerializer(serializers.ModelSerializer):
    created_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    updated_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    member_details = serializers.SerializerMethodField(read_only=False)
    form_details = serializers.SerializerMethodField(read_only=False)
    total_member_in_group = serializers.SerializerMethodField(read_only=False)
    assign_jobs = serializers.SerializerMethodField(read_only=False)
    image = ImageField(required=False)
    form = serializers.PrimaryKeyRelatedField(
        queryset=Form.objects.all(),
        required=False,
        many=True,
    )

    class Meta:
        model = Group
        fields = "__all__"

    # def create(self, validated_data):
    #     instance = super().create(validated_data)
    #     if "image" in validated_data:
    #         image = validated_data.pop("image")
    #         instance.image = image
    #     instance.save()
    #     return instance

    def get_total_member_in_group(self, obj):
        return obj.member.count()

    def get_member_details(self, obj):
        return User_serializers.CustomUserSerializers(
            obj.member, many=True, context=self.context
        ).data

    def get_form_details(self, obj):
        return FormSerializer(obj.form, many=True, context=self.context).data

    def get_assign_jobs(self, obj):
        assign_job = TransferJob.objects.filter(
            group=obj,
            status__in=[
                JobStatus.OPEN,
                JobStatus.PARTIAL,
                JobStatus.RETURN,
                JobStatus.TRANSFER,
            ],
        ).exclude(group__is_archive=True)

        return GetTransferJobSerializers(
            assign_job, many=True, context=self.context
        ).data

    def update(self, instance, validated_data):
        instance = super().update(instance, validated_data)
        instance.updated_by = self.context["request"].user
        instance.save()
        return instance


class CustomGroupSerializer(serializers.ModelSerializer):
    total_member_in_group = serializers.SerializerMethodField(read_only=False)

    class Meta:
        model = Group
        fields = [
            "id",
            "name",
            "image",
            "total_member_in_group",
            "created_at",
        ]

    def get_total_member_in_group(self, obj):
        return obj.member.count()


class CustomArchiveGroupSerializer(serializers.ModelSerializer):
    created_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    updated_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    member_details = serializers.SerializerMethodField(read_only=False)
    form_details = serializers.SerializerMethodField(read_only=False)
    total_member_in_group = serializers.SerializerMethodField(read_only=False)
    assign_jobs = serializers.SerializerMethodField(read_only=False)

    class Meta:
        model = Group
        fields = "__all__"

    def get_total_member_in_group(self, obj):
        return obj.member.count()

    def get_member_details(self, obj):
        return User_serializers.CustomUserSerializers(
            obj.member, many=True, context=self.context
        ).data

    def get_form_details(self, obj):
        return FormSerializer(obj.form, many=True, context=self.context).data

    def get_assign_jobs(self, obj):
        assign_job = TransferJob.objects.filter(
            group=obj, group__is_archive=True
        ).values_list("job", flat=True)
        jobs = Job.objects.filter(id__in=assign_job)
        return GetJobCreateSerializer(jobs, many=True, context=self.context).data
