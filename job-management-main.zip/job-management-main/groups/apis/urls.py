from django.urls import include
from django.urls import path
from rest_framework.routers import DefaultRouter

from groups.apis.views import GroupArchiveView
from groups.apis.views import GroupView

router = DefaultRouter()
router.register("", GroupView, basename="session_auth")

urlpatterns = [
    path("archive/", GroupArchiveView.as_view({"get": "list"}), name="archive_list"),
    path(
        "archive/<int:pk>",
        GroupArchiveView.as_view({"get": "retrieve"}),
        name="archive_list",
    ),
    path("", include(router.urls)),
]
