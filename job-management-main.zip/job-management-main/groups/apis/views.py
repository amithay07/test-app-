from django.db.models import Count
from rest_framework import filters
from rest_framework import status
from rest_framework import viewsets
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response

from groups.apis.serializers import CustomArchiveGroupSerializer
from groups.apis.serializers import CustomGroupSerializer
from groups.apis.serializers import GroupSerializer
from users.models.group import Group
from users.models.user import User
from users.permission import UserPermission


class GroupView(viewsets.ModelViewSet):
    """
    Create, Update, Delete, List, Retrive for Admin
    List, Retrive for Group-Admin
    List, Retrive for Inspector
    """

    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    parser_classes = [MultiPartParser]
    filter_backends = [filters.SearchFilter]
    search_fields = ["name"]

    view_permissions = {
        "list": {
            "admin": True,
            "inspector": True,
            "group_manger": True,
            "simple_user": True,
        },
        "retrieve": {
            "admin": True,
            "inspector": True,
            "group_manger": True,
            "simple_user": True,
        },
        "create": {"admin": True},
        "destroy": {"admin": True},
        "partial_update": {"admin": True},
    }

    def create(self, request, *args, **kwargs):
        data = request.data.copy()
        member = data.getlist("member")
        member.append(str(request.user.id))
        data.setlist("member", member)
        serializer = self.serializer_class(data=data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        instance = serializer.data["id"]
        users = User.objects.filter(id__in=member)
        for user in users:
            user.permissions.add(instance)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def list(self, request, *args, **kwargs):
        queryset = self.paginate_queryset(
            self.filter_queryset(
                self.get_queryset()
                .filter(member=request.user.id)
                .annotate(Count("id"))
                .order_by("-created_at")
                .exclude(is_archive=True)
            )
            if not request.user.is_superuser
            else self.filter_queryset(
                Group.objects.exclude(is_archive=True).order_by("-created_at")
            )
        )
        seralizer = CustomGroupSerializer(
            queryset, many=True, context={"request": request}
        )
        return self.get_paginated_response(seralizer.data)

    def retrieve(self, request, *args, **kwargs):
        if request.user.id in self.get_object().member.values_list("id", flat=True):
            serializer = self.get_serializer(self.get_object())
            return Response(serializer.data)
        elif request.user.is_superuser:
            serializer = self.get_serializer(self.get_object())
            return Response(serializer.data, status=status.HTTP_200_OK)
        # {"detail": "You do not have permission to perform this action."}
        return Response(
            {"detail": "אין לך הרשאה לביצוע פעולה זו"},
            status=status.HTTP_403_FORBIDDEN,
        )

    def partial_update(self, request, *args, **kwargs):
        data = request.data
        group_permissions = data.getlist("member")
        instance = self.get_object()
        group = Group.objects.filter(id=kwargs["pk"]).first()
        kwargs["partial"] = True

        instance.groups.clear()
        instance.groups.add(*group_permissions)

        superuser_id = User.objects.filter(is_superuser=True).first()
        group_permissions.append(str(superuser_id.id))

        for permission in group_permissions:
            users = User.objects.filter(id=permission).first()
            users.permissions.add(group.id)

        return self.update(request, *args, **kwargs)


class GroupArchiveView(viewsets.ModelViewSet):
    queryset = Group.objects.all()
    serializer_class = CustomArchiveGroupSerializer
    permission_classes = [UserPermission]
    filter_backends = [filters.SearchFilter]
    search_fields = ["name"]

    def list(self, request, *args, **kwargs):
        instance = self.paginate_queryset(
            self.filter_queryset(
                self.queryset.filter(is_archive=True).order_by("-created_at")
            )
        )
        serializer = self.serializer_class(
            instance, many=True, context={"request": request}
        )
        return self.get_paginated_response(serializer.data)

    def retrieve(self, request, *args, **kwargs):
        instance = Group.objects.filter(id=kwargs["pk"], is_archive=True).first()
        if not instance:
            # {"detail": "The group was not found"}
            return Response(
                {"detail": "קבוצה לא נמצאה"},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = self.serializer_class(instance, context={"request": request})
        return Response(serializer.data, status=status.HTTP_200_OK)
