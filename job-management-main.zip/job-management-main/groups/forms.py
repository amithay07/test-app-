from django import forms

from users.models.form import Form
from users.models.group import Group


class GroupCreateForm(forms.ModelForm):
    form = forms.ModelMultipleChoiceField(
        queryset=Form.objects.all(),
        required=False,
    )
    image = forms.ImageField(required=False)

    class Meta:
        model = Group
        fields = "__all__"


class GroupUpdateForm(forms.ModelForm):
    form = forms.ModelMultipleChoiceField(
        queryset=Form.objects.all(),
        required=False,
    )
    image = forms.ImageField(required=False)

    class Meta:
        model = Group
        exclude = ["created_by"]
