from django.db.models.signals import post_save
from users.models import Group
from django.dispatch import receiver
from chat.models import Chat

@receiver(post_save, sender=Group)
def create_group_invitation_link(sender, instance, created, **kwargs):
    if created:
        Chat.objects.create(group=instance)