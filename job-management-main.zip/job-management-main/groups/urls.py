from django.urls import path

from groups.views import GroupCreateView
from groups.views import GroupListView
from groups.views import GroupUpdateView

app_name = "groups"
urlpatterns = [
    path("", GroupListView.as_view(), name="group-list"),
    path("group-add/", GroupCreateView.as_view(), name="group-add"),
    path("group-update/<int:pk>/", GroupUpdateView.as_view(), name="group-update"),
]
