from django.contrib.auth.decorators import login_required
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger
from django.core.paginator import Paginator
from django.db.models import Count
from django.db.models import Q
from django.http import JsonResponse
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views.generic import CreateView
from django.views.generic import ListView
from django.views.generic import UpdateView

from groups.forms import GroupCreateForm
from groups.forms import GroupUpdateForm
from jobs.views import NotificationList
from users.models.form import Form
from users.models.group import Group
from users.models.job import TransferJob
from users.models.role import UserRoleChoices
from users.models.user import User
from users.permission import OnlyForAdmin
from users.templatetags.myfilters import get_first_image
from users.utils import get_query_params


@method_decorator(login_required, name="dispatch")
class GroupListView(ListView):
    model = Group
    template_name = "group.html"
    success_url = reverse_lazy("groups:group-list")
    queryset = Group.objects.annotate(member_count=Count("member")).order_by("-created_at")

    def get_queryset(self):
        queryset = super().get_queryset()
        user = self.request.user
        search = self.request.GET.get("search")
        group = self.request.GET.get("group", "Unarchive")
        if not user.is_superuser:
            queryset = user.group_member.all()
        if search:
            return (
                queryset.filter(name__icontains=search, is_archive=False)
                if group == "Unarchive"
                else queryset.filter(name__icontains=search, is_archive=True)
            )
        return (
            queryset.filter(is_archive=False)
            if group == "Unarchive"
            else queryset.filter(is_archive=True)
        )

    def get_context_data(self, **kwargs):
        queryset = self.object_list
        (from_date, to_date) = get_query_params(self.request.GET)
        group = self.request.GET.get("group", "Unarchive")
        page_number = self.request.GET.get("page")
        groups = (
            queryset.filter(created_at__date__range=[from_date, to_date])
            if from_date and to_date
            else queryset
        )
        paginator = Paginator(groups, 10)
        groups_list = paginator.get_page(page_number)

        try:
            page_range = paginator.page(page_number)
        except PageNotAnInteger:
            page_range = paginator.page(1)
        except EmptyPage:
            page_range = paginator.page(paginator.num_pages)

        context = super().get_context_data(
            **kwargs,
            page_range=page_range,
            paginator=paginator,
            group=group,
            groups=groups_list,
            member_list=list(
                User.objects.exclude(is_deleted=True).select_related("role")
            ),
            form_list=list(Form.objects.order_by("-created_at")),
            from_date=from_date,
            to_date=to_date,
            notification=NotificationList(self)
        )
        return context


@method_decorator(login_required, name="dispatch")
class GroupCreateView(OnlyForAdmin, CreateView):
    model = Group
    form_class = GroupCreateForm
    template_name = "group.html"
    success_url = reverse_lazy("groups:group-list")

    def post(self, request, *args, **kwargs):
        data = request.POST.dict()
        user_list = request.POST.getlist("member")
        data["member"] = user_list + [str(request.user.id)]
        data["form"] = request.POST.getlist("form")
        group = self.form_class(data, request.FILES)
        users = User.objects.filter(id__in=user_list)
        group_users_role = set(
            users.filter(
                Q(role__title=UserRoleChoices.ADMIN.value),
            )
            .exclude(Q(role__title=UserRoleChoices.USER.value))
            .values_list("role__title", flat=True)
        )
        if len(group_users_role) != 1:
            return JsonResponse(
                {"error": {"member": _("At least one Admin as Group Member")}}
            )
        if group.is_valid():
            group.instance.created_by = request.user
            group.instance.updated_by = request.user
            instance = group.save()
            for user in users:
                user.permissions.add(instance.id)
            return JsonResponse({"create_group_status": "success"})
        return JsonResponse({"error": group.errors if group.errors else None})


@method_decorator(login_required, name="dispatch")
class GroupUpdateView(UpdateView):
    model = Group
    form_class = GroupUpdateForm
    template_name = "group.html"
    success_url = reverse_lazy("groups:group-list")

    def get(self, request, *args, **kwargs):
        group_id = kwargs.get("pk")
        instance = self.model.objects.filter(id=group_id)
        response = list(instance.values())
        members = list(getattr(instance.first(), "member").values_list("id", flat=True))
        forms = list(getattr(instance.first(), "form").values_list("id", flat=True))
        jobs = (
            TransferJob.objects.prefetch_related("job__job_image")
            .filter(group_id=group_id)
            .order_by("-created_at")
        )

        group_job = []
        for job in jobs:
            get_image = get_first_image(job.job)
            job = [
                {
                    "job_address": job.job.address,
                    "job_status": job.status,
                    "job_image": get_image if get_image else None,
                    "job_priority": job.job.priority,
                    "job_created_at": job.job.created_at.strftime("%d %B %Y"),
                }
            ]
            group_job.append(job)
        return JsonResponse(
            {
                "data": response,
                "members": members,
                "forms": forms,
                "group_job": group_job,
            }
        )

    def post(self, request, *args, **kwargs):
        id = kwargs.get("pk")
        group = Group.objects.get(id=id)
        permissions = User.objects.exclude(is_deleted=True).filter(permissions__id=id)
        for permission in permissions:
            if not request.user.id:
                permission.permissions.remove(id)
        if request.POST.getlist("member"):
            users = User.objects.filter(id__in=request.POST.getlist("member"))
            group_users_role = set(
                users.filter(
                    Q(role__title=UserRoleChoices.ADMIN.value),
                )
                .exclude(Q(role__title=UserRoleChoices.USER.value))
                .values_list("role__title", flat=True)
            )
            if len(group_users_role) != 1:
                return JsonResponse(
                    {"error": {"member": _("At least one Admin as Group Member")}}
                )
            for user in users:
                user.permissions.add(id)
        super().post(request, *args, **kwargs)
        group.member.add(request.user.id)
        return JsonResponse({"create_group_status": "success"})

    def form_valid(self, form, **kwargs):
        form.instance.updated_by = self.request.user
        form.save()
        return JsonResponse({"update_group_status": "success"})

    def form_invalid(self, form):
        return JsonResponse({"error": form.errors if form.errors else None})
