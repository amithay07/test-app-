from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth.models import Group
from django.contrib.auth.views import LoginView
from django.contrib.auth.views import LogoutView
from django.contrib.auth.views import PasswordChangeView
from django.contrib.auth.views import PasswordResetCompleteView
from django.contrib.auth.views import PasswordResetConfirmView
from django.contrib.auth.views import PasswordResetDoneView
from django.urls import include
from django.urls import path
from django.urls import re_path
from django.urls import reverse_lazy
from django.views.generic import TemplateView
from drf_yasg import openapi
from drf_yasg.views import get_schema_view
from fcm_django.models import FCMDevice
from rest_framework import permissions

from jobs.views import DashboardView
from users.apis.views import ForgotPasswordView
from users.apis.views import TokenObtainPairView
from users.forms import AuthenticationForm
from users.forms import SetPasswordForm
from users.views import ChangePasswordView
from users.views import ResendInvitationView
from users.views import ResetPasswordView
from users.views import UserProfileView

PasswordChangeView.success_url = reverse_lazy("change-password")
schema_view = get_schema_view(
    openapi.Info(title="Job-Management API", default_version="v1"),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

# from django.contrib.auth.urls
urlpatterns = [
    path("", DashboardView.as_view(), name="index"),
    path("__debug__/", include("debug_toolbar.urls")),
    path("i18n/", include("django.conf.urls.i18n")),
    path("admin/", admin.site.urls),
    path(
        "accounts/login/",
        LoginView.as_view(form_class=AuthenticationForm),
        name="login",
    ),
    path(
        "accounts/logout/",
        LogoutView.as_view(),
        name="logout",
    ),
    path(
        "accounts/password-reset/",
        ResetPasswordView.as_view(
            template_name="registration/forgot-password.html",
            subject_template_name="registration/reset_password_subject.txt",
            html_email_template_name="registration/email.html",
            email_template_name="registration/email.html",
        ),
        name="password-reset",
    ),
    path(
        "accounts/password-reset/done/",
        PasswordResetDoneView.as_view(
            template_name="registration/password_reset.html",
        ),
        name="password-reset-mail-done",
    ),
    path(
        "accounts/password-reset-confirm/<uidb64>/<token>/",
        PasswordResetConfirmView.as_view(
            form_class=SetPasswordForm,
            template_name="registration/password_forgot_confirm.html",
            success_url=reverse_lazy("password-forgot-complete"),
        ),
        name="password-forgot-confirm",
    ),
    path(
        "accounts/password-reset-complete/",
        PasswordResetCompleteView.as_view(
            template_name="registration/password_forgot_complete.html"
        ),
        name="password-forgot-complete",
    ),
    path(
        "accounts/password-set-confirm/<uidb64>/<token>/",
        PasswordResetConfirmView.as_view(
            form_class=SetPasswordForm,
            template_name="registration/password_set_confirm.html",
            success_url=reverse_lazy("password-set-complete"),
        ),
        name="password-set-confirm",
    ),
    path(
        "accounts/password-set-complete/",
        PasswordResetCompleteView.as_view(
            template_name="registration/password_set_complete.html"
        ),
        name="password-set-complete",
    ),
    path("accounts/profile/", UserProfileView.as_view(), name="user-profile"),
    path(
        "accounts/change-password/",
        ChangePasswordView.as_view(
            template_name="registration/change_password.html",
        ),
        name="user-change-password",
    ),
    path(
        "users/resend-invitation/<int:pk>/",
        ResendInvitationView.as_view(),
        name="resend-invitation",
    ),
    path("api/users/", include("users.apis.urls")),
    path("api/job/", include("jobs.apis.urls")),
    path("api/groups/", include("groups.apis.urls")),
    path("api/auth/signin/", TokenObtainPairView.as_view(), name="token-access"),
    path("api/bills/", include("bills.apis.urls")),
    path("api/forms/", include("forms.apis.urls")),
    path("api/chat/", include("chat.apis.urls")),
    path(
        "api/auth/reset-password/",
        ForgotPasswordView.as_view(),
        name="forgot-password",
    ),
    re_path(
        r"^doc(?P<format>\.json|\.yaml)$",
        schema_view.without_ui(cache_timeout=0),
        name="Schema-json",
    ),
    path(
        "api/docs/",
        schema_view.with_ui("swagger", cache_timeout=0),
        name="Schema-swagger-ui",
    ),
    path(
        "redoc/",
        schema_view.with_ui("redoc", cache_timeout=0),
        name="Schema-redoc",
    ),
    path("users/", include("users.urls")),
    path("bills/", include("bills.urls")),
    path("jobs/", include("jobs.urls")),
    path("forms/", include("forms.urls")),
    path("groups/", include("groups.urls")),
    path("chats/", include("chat.urls")),
    path(
        "privacy-policy/",
        TemplateView.as_view(template_name="bochan_private_policy.html"),
        name="bochan_private_policy",
    ),
]
if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL, document_root=settings.MEDIA_ROOT
    ) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


admin.site.unregister(FCMDevice)
admin.site.unregister(Group)
