from django.contrib import admin

from chat.models import TempChatAttestment

admin.site.register(TempChatAttestment)
# Register your models here.
