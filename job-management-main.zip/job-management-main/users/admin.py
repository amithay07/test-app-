from django.contrib import admin

from users.models.user import User


class UserAdmin(admin.ModelAdmin):
    list_display = ["email", "user_name", "role", "is_active"]
    view_on_site = False
    search_fields = ("email", "user_name")
    list_filter = ("role",)
    fields = (
        "first_name",
        "user_name",
        "email",
        "phone",
        "role",
        "is_active",
        "is_superuser",
    )

    def get_queryset(self, request):
        return User.all_objects.all()

    def has_add_permission(self, request, obj=None):
        return False

    def save_model(self, request, obj, form, change):
        if obj.is_active and obj.is_deleted:
            obj.is_deleted = False
            obj.save()
        super().save_model(request, obj, form, change)


admin.site.register(User, UserAdmin)
