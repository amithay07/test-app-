import os

from django.db.models import Sum
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from groups.apis.serializers import PermissionGroupSerializer
from users.models.role import UserRole
from users.models.role import UserRoleChoices
from users.models.user import TempUser
from users.models.user import User
from users.utils import fcm_update


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRole
        fields = "__all__"


class GetUserSerializers(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ("id", "profile_image", "user_name", "email", "role", "date_joined")

    def get_role(self, obj):
        return RoleSerializer(obj.role, read_only=True, context=self.context).data


class GetCustomUserSerializers(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    permissions = serializers.SerializerMethodField()
    user_in_groups = serializers.SerializerMethodField()
    profile_image = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = (
            "id",
            "profile_image",
            "user_name",
            "email",
            "phone",
            "permissions",
            "all_permissions",
            "role",
            "is_active",
            "user_in_groups",
            "is_superuser",
            "date_joined",
        )

    def get_profile_image(self, obj):
        URL = os.environ["URL"]
        if obj.profile_image:
            if int(os.environ["USE_S3"]):
                return f"{URL}{obj.profile_image}"
            else:
                return f"{URL}media/{obj.profile_image}"
        else:
            return None

    def get_role(self, obj):
        return RoleSerializer(obj.role, read_only=True, context=self.context).data

    def get_permissions(self, obj):
        return PermissionGroupSerializer(
            obj.permissions, many=True, context=self.context
        ).data

    def get_user_in_groups(self, obj):
        if obj.role == UserRoleChoices.GROUP_MANAGER.value:
            return PermissionGroupSerializer(
                obj.group_member.all(), many=True, context=self.context
            ).data
        return PermissionGroupSerializer(
            obj.group_member.all(), many=True, context=self.context
        ).data


class CustomUserSerializers(serializers.ModelSerializer):
    from rest_framework.validators import UniqueValidator

    email = serializers.EmailField(
        max_length=255, validators=[UniqueValidator(queryset=User.all_objects.all())]
    )
    user_name = serializers.CharField(
        max_length=255, validators=[UniqueValidator(queryset=User.all_objects.all())]
    )

    class Meta:
        model = User
        fields = (
            "id",
            "profile_image",
            "user_name",
            "email",
            "phone",
            "permissions",
            "all_permissions",
            "role",
            "is_superuser",
        )

    # def create(self, validated_data):
    #     profile_image = None
    #     if "profile_image" in validated_data:
    #         profile_image = validated_data.pop("profile_image")
    #     instance = super().create(validated_data)
    #     if profile_image:
    #         instance.profile_image = profile_image
    #         instance.save()
    #     return instance


class UserUpdateSerializers(serializers.ModelSerializer):
    permissions = serializers.SerializerMethodField()
    title = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = (
            "id",
            "profile_image",
            "user_name",
            "email",
            "phone",
            "permissions",
            "all_permissions",
            "role",
            "title",
        )

    def get_permissions(self, obj):
        return PermissionGroupSerializer(
            obj.permissions, many=True, context=self.context
        ).data

    def get_title(self, obj):
        return obj.role.title


class ChangePasswordSerializers(serializers.ModelSerializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    class Meta:
        model = User
        fields = ("old_password", "new_password")


class TokenObtainLifetimeSerializer(TokenObtainPairSerializer):
    device_id = serializers.CharField(required=False, write_only=True)
    fcm_token = serializers.CharField(required=False, write_only=True)
    device_type = serializers.CharField(required=False, write_only=True)
    default_error_messages = {"no_active_account": _("לא הצליח למצוא את החשבון שלך")}

    def validate(self, attrs):
        data = super().validate(attrs)
        role = getattr(self.user, "role")
        user = GetCustomUserSerializers(self.user, context=self.context).data
        total_unread_message_count = self.user.unread_messages.values(
            "unread_message_count"
        ).annotate(total_unread_message_count=Sum("unread_message_count"))
        data.update(
            {
                "role": role.title,
                "user": user,
                "total_unread_message_count": list(total_unread_message_count)[-1][
                    "total_unread_message_count"
                ]
                if total_unread_message_count
                else 0,
            }
        )
        if (
            attrs.get("fcm_token")
            and attrs.get("device_id")
            and attrs.get("device_type")
        ):
            fcm_update(
                registration_id=attrs.get("fcm_token"),
                device_id=attrs.get("device_id"),
                type=attrs.get("device_type"),
                user=self.user,
            )
        return data


class UserRoleSerializers(serializers.ModelSerializer):
    class Meta:
        model = UserRole
        fields = "__all__"


class ProfileUpdateSerializers(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            "id",
            "profile_image",
            "user_name",
            "email",
            "phone",
            "is_active",
            "is_superuser",
        )


class TempUserSerializers(serializers.ModelSerializer):
    class Meta:
        model = TempUser
        fields = "__all__"
