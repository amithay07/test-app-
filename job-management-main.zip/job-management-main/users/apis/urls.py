from django.urls import include
from django.urls import path
from rest_framework.routers import DefaultRouter

from users.apis.views import ApiViewSet
from users.apis.views import ChangePasswordView
from users.apis.views import InspectorAndManagerInfo
from users.apis.views import RoleListView
from users.apis.views import TempUserView
from users.apis.views import UserCountView
from users.apis.views import UserInfoView
from users.apis.views import UserProfileUpdateView

router = DefaultRouter()
router.register("", ApiViewSet, basename="session_auth")


urlpatterns = [
    path("group/", InspectorAndManagerInfo.as_view({"get": "list"}), name="inspector"),
    path("info/", UserInfoView.as_view(), name="info"),
    path("role/", RoleListView.as_view(), name="role"),
    path("change-password/", ChangePasswordView.as_view(), name="change-password"),
    path("profile-update/", UserProfileUpdateView.as_view(), name="profile-update"),
    path("counts/", UserCountView.as_view(), name="user-counts"),
    path("temp-user-create/", TempUserView.as_view(), name="temp-user-create"),
    path("", include(router.urls)),
]
