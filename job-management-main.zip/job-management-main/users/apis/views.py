import datetime
import os
from datetime import date

from django.conf import settings
from django.contrib.auth.forms import PasswordResetForm
from django.db.models import Q
from django.db.models import Sum
from django_filters.rest_framework import DjangoFilterBackend
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import filters
from rest_framework import status
from rest_framework import viewsets
from rest_framework.generics import CreateAPIView
from rest_framework.generics import ListAPIView
from rest_framework.generics import ListCreateAPIView
from rest_framework.generics import RetrieveAPIView
from rest_framework.generics import UpdateAPIView
from rest_framework.parsers import MultiPartParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.views import TokenViewBase

from users.apis.serializers import ChangePasswordSerializers
from users.apis.serializers import CustomUserSerializers
from users.apis.serializers import GetCustomUserSerializers
from users.apis.serializers import ProfileUpdateSerializers
from users.apis.serializers import TempUserSerializers
from users.apis.serializers import TokenObtainLifetimeSerializer
from users.apis.serializers import UserRoleSerializers
from users.apis.serializers import UserUpdateSerializers
from users.models.group import Group
from users.models.job import ReturnJob
from users.models.job import TransferJob
from users.models.role import UserRole
from users.models.role import UserRoleChoices
from users.models.user import TempUser
from users.models.user import User
from users.permission import UserPermission
from users.utils import send_email


class TokenObtainPairView(TokenViewBase):
    """
    Return JWT tokens (access and refresh) for specific user based on username and password.
    """

    serializer_class = TokenObtainLifetimeSerializer

    def post(self, request, *args, **kwargs):
        email = request.data["email"].lower()
        user = User.all_objects.filter(email__iexact=email).first()
        if user:
            if user.is_deleted:
                return Response(
                    {
                        "message": "החשבון שלך נמחק. כדי להפעיל את חשבונך, צור קשר עם התמיכה תוך 15 יום ממועד המחיקה"
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
            if not user.is_active:
                user.is_active = True
                user.save()

            data = request.data.dict()
            data["email"] = email
            serializer = self.serializer_class(data=data)
            serializer.is_valid(raise_exception=True)
            User.all_objects.filter(email__iexact=email).update(
                last_login=datetime.datetime.today()
            )
            return Response(serializer.validated_data)

        temp_user = TempUser.objects.filter(email__iexact=email).first()
        if temp_user:
            return Response(
                {"message": "החשבון שלך נמצא כעת בתהליך אימות!"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return Response(
            {"message": "לא הצליח למצוא את החשבון שלך"},
            status=status.HTTP_401_UNAUTHORIZED,
        )


class ApiViewSet(viewsets.ModelViewSet):
    queryset = User.objects.exclude(is_deleted=True)
    serializer_class = CustomUserSerializers
    authentication_classes = [JWTAuthentication]
    parser_classes = [MultiPartParser]
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    search_fields = ["id", "user_name"]
    filterset_fields = ["is_active"]

    view_permissions = {
        "list": {"inspector": False, "admin": True, "group_manger": True},
        "retrieve": {"inspector": True, "admin": True, "group_manger": True},
        "create": {"is_superuser": True},
        "partial_update": {"is_superuser": True},
        "destroy": {"is_superuser": True},
    }

    def get_serializer(self, *args, **kwargs):
        if self.action == "partial_update":
            serializer_class = UserUpdateSerializers
            return serializer_class(*args, **kwargs, context={"request": self.request})
        else:
            serializer_class = GetCustomUserSerializers
            return serializer_class(*args, **kwargs, context={"request": self.request})

    def retrieve(self, request, *args, **kwargs):
        if request.user.is_superuser:
            lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
            instance = (
                User.all_objects.exclude(is_deleted=True)
                .filter(id=self.kwargs[lookup_url_kwarg])
                .first()
            )
        else:
            instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    def list(self, request, *args, **kwargs):
        page = self.paginate_queryset(
            self.filter_queryset(
                User.all_objects.exclude(is_deleted=True)
                .exclude(id=request.user.id)
                .order_by("-date_joined")
            )
        )
        serializer = GetCustomUserSerializers(
            page, many=True, context={"request": request}
        )
        return self.get_paginated_response(serializer.data)

    @swagger_auto_schema(request_body=CustomUserSerializers)
    def create(self, request):
        if request.data.get("all_permissions") == "true":
            group_permissions = (
                Group.objects.all()
                .values_list("id", flat=True)
                .exclude(is_archive=True)
            )
            group_permissions = list(group_permissions)
        elif request.data.getlist("permissions"):
            group_permissions = [
                int(x) for x in request.data.getlist("permissions")[0].split(",")
            ]
        else:
            group_permissions = []

        serializer = CustomUserSerializers(
            data=request.data, context={"request": request}
        )
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        user.permissions.add(*group_permissions)
        user_mail = self.request.data.get("email")
        users = PasswordResetForm.get_users(self, user_mail)
        user_name = User.objects.get(email__iexact=user_mail)
        context = {"user_name": user_name.user_name}

        send_email(self, users, context)
        PasswordResetForm.send_mail(
            self,
            "registration/set_password_subject.txt",
            "registration/set_password_email.html",
            context,
            settings.FROM_EMAIL_ADDRESS,
            user_mail,
            html_email_template_name="registration/set_password_email.html",
        )

        for permission in request.data.getlist("permissions"):
            users = Group.objects.filter(id=permission, is_archive=False).first()
            users.member.add(user.id)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def partial_update(self, request, *args, **kwargs):
        data = request.data
        kwargs["partial"] = True
        group_permissions = data.getlist("permissions")
        instance = self.get_object()
        users = User.objects.filter(id=kwargs["pk"]).first()
        user_role_id = str(users.role_id)
        if "role" in data and str(users.role) == UserRoleChoices.ADMIN.value:
            if data["role"] != str(users.role_id):
                groups_id = users.permissions.values_list("name", flat=True)
                records = Group.objects.filter(name__in=groups_id)

                group_names = ""
                for record in records:
                    count = (
                        record.member.filter(role__title=UserRoleChoices.ADMIN.value)
                        .exclude(id=User.objects.filter(is_superuser=True).first().id)
                        .count()
                    )
                    if count == 1:
                        group_names += record.name + ", "

                if group_names:
                    # {"detail": f"You do not change the Admin role, please add group manager in this {record.name} group"}
                    return Response(
                        {
                            "detail": f"אינך משנה את תפקיד מנהל מערכת, אנא הוסף את מנהל הקבוצה לקבוצת {group_names} זו."
                        },
                        status=status.HTTP_400_BAD_REQUEST,
                    )

        instance.permissions.clear()
        instance.permissions.add(*group_permissions)
        instance.group_member.clear()
        instance.group_member.add(*group_permissions)
        if request.data.get("all_permissions") == "true":
            group_permissions = (
                Group.objects.all()
                .values_list("id", flat=True)
                .exclude(is_archive=True)
            )
            group_permissions = list(group_permissions)
        elif request.data.getlist("permissions"):
            group_permissions = [
                int(x) for x in request.data.getlist("permissions")[0].split(",")
            ]
        else:
            group_permissions = []
        serializer = UserUpdateSerializers(
            users, data=data, context={request: self.request}
        )
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        user.permissions.add(*group_permissions)
        users.save()
        for permission in group_permissions:
            users = Group.objects.filter(id=permission, is_archive=False).first()
            users.member.add(user.id)

        if data["role"] != user_role_id:
            User.objects.filter(id=kwargs["pk"]).update(
                restrict_login_before=datetime.datetime.today()
            )
        return Response(serializer.data, status=status.HTTP_202_ACCEPTED)

    def destroy(self, request, *args, **kwargs):
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        instance = User.all_objects.filter(id=self.kwargs[lookup_url_kwarg]).first()
        records = Group.objects.filter(member=instance)
        for record in records:
            if not record.member.filter(role=instance.role).exists():
                # {"detail": f"Before deleting the user, add another user in group {record.name} with role {instance.role.title}."}
                return Response(
                    {
                        "detail": f"לפני מחיקת המשתמש, אנא הוסף לקבוצה {record.name} משתמש נוסף בתפקיד {instance.role.title}"
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
        instance.is_deleted = True
        instance.is_active = False
        instance.save()
        # {"detail": "User deleted successfully"}
        return Response(
            {"detail": "משתמש נמחק בהצלחה"}, status=status.HTTP_202_ACCEPTED
        )


class ForgotPasswordView(APIView):
    view_permissions = {"post": {"anon": True}}

    def post(self, request):
        user_mail = self.request.data.get("email")
        if (
            User.objects.exclude(is_deleted=True)
            .filter(email__iexact=user_mail, is_active=True)
            .exists()
        ):
            users = PasswordResetForm.get_users(self, user_mail)
            context = {}
            send_email(self, users, context)
            PasswordResetForm.send_mail(
                self,
                "registration/reset_password_subject.txt",
                "registration/email.html",
                context,
                settings.FROM_EMAIL_ADDRESS,
                user_mail,
                html_email_template_name="registration/email.html",
            )
            # {"detail": "Email send successfully"}
            return Response({"detail": "אימייל נשלח בהצלחה"}, status=status.HTTP_200_OK)
            # {"detail": "Email not found or User is inactive"}
        return Response(
            {"detail": "מייל לא נמצאה ואו משתמש אינו פעיל"},
            status=status.HTTP_404_NOT_FOUND,
        )


class ChangePasswordView(UpdateAPIView):
    serializer_class = ChangePasswordSerializers
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def update(self, request, *args, **kwargs):
        user = self.request.user
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        if not user.check_password(serializer.data.get("old_password")):
            # {"detail": "Wrong password."}
            return Response(
                {"detail": "סיסמא שגויה"}, status=status.HTTP_400_BAD_REQUEST
            )
        user.set_password(serializer.data.get("new_password"))
        user.save()
        # {"detail": "Password updated successfully"}
        return Response(
            {"detail": "הסיסמא עודכנה בהצלחה"}, status=status.HTTP_202_ACCEPTED
        )


class UserInfoView(RetrieveAPIView):
    model = User
    serializer_class = GetCustomUserSerializers
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return self.model.objects.get(
                pk=self.request.user.pk,
                is_active=True,
            )
        except:
            # {"detail": "Not Found"}
            return Response(
                {"detail": "לא נמצא"},
                status=status.HTTP_404_NOT_FOUND,
            )


class RoleListView(ListAPIView):
    queryset = UserRole.objects.all()
    serializer_class = UserRoleSerializers
    permission_classes = [UserPermission]


class InspectorAndManagerInfo(viewsets.ModelViewSet):
    queryset = User.objects.exclude(is_deleted=True)
    serializer_class = GetCustomUserSerializers
    permission_classes = [UserPermission]
    authentication_classes = [JWTAuthentication]

    role = openapi.Parameter(
        "role",
        openapi.IN_QUERY,
        required=False,
        description="Role should be מְפַקֵחַ or מנהל קבוצה ",
        type=openapi.TYPE_STRING,
    )

    @swagger_auto_schema(manual_parameters=[role])
    def list(self, request, *args, **kwargs):
        role = self.request.query_params.get("role", None)
        data = (
            self.get_queryset().exclude(Q(role__title=UserRoleChoices.ADMIN.value))
            if not role
            else self.get_queryset().filter(role__title=role)
        )
        instance = self.paginate_queryset(data)
        serializer = self.get_serializer(
            instance, many=True, context={"request": request}
        )
        return self.get_paginated_response(serializer.data)


class UserProfileUpdateView(UpdateAPIView):
    queryset = User.objects.exclude(is_deleted=True)
    serializer_class = ProfileUpdateSerializers
    parser_classes = [MultiPartParser]
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        user = self.request.user
        serializer = self.serializer_class(
            user,
            data=request.data,
            context={"request": self.request},
            partial=True,
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_202_ACCEPTED)


class UserCountView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        total_unread_message_count = self.request.user.unread_messages.values(
            "unread_message_count"
        ).annotate(total_unread_message_count=Sum("unread_message_count"))
        response = {}
        if request.user.role.title == UserRoleChoices.GROUP_MANAGER.value:
            group_list = Group.objects.filter(
                member=request.user, is_archive=False
            ).values_list("id", flat=True)
            transfer_job_count = (
                TransferJob.objects.filter(group__in=group_list)
                .exclude(group__is_archive=True)
                .count()
            )
            response.update({"total_transfer_job_count": transfer_job_count})

        elif request.user.role.title in [
            UserRoleChoices.ADMIN.value,
            UserRoleChoices.INSPECTOR.value,
        ]:
            total_return_job_count = (
                ReturnJob.objects.filter(
                    return_to=request.user.id, status__in=["מידע שגוי", "לְשַׁכְפֵּל"]
                )
                .exclude(
                    job_id__in=TransferJob.objects.filter(
                        group__is_archive=True
                    ).values_list("id", flat=True)
                )
                .count()
                if not request.user.is_superuser
                else ReturnJob.objects.filter(status__in=["מידע שגוי", "לְשַׁכְפֵּל"])
                .exclude(
                    job_id__in=TransferJob.objects.filter(
                        group__is_archive=True
                    ).values_list("id", flat=True)
                )
                .count()
            )

            response.update({"total_return_job_count": total_return_job_count})

        response.update(
            {
                "total_unread_message_count": list(total_unread_message_count)[-1][
                    "total_unread_message_count"
                ]
                if total_unread_message_count
                else None
            }
        )
        return Response(response, status=status.HTTP_200_OK)


class TempUserView(CreateAPIView):
    serializer_class = TempUserSerializers
    view_permissions = {"post": {"anon": True}}

    @swagger_auto_schema(request_body=TempUserSerializers)
    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(
            data=request.data,
            context={"request": request},
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)
