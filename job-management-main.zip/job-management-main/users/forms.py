import re
from threading import Thread
from django import forms
from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth.forms import AuthenticationForm as BaseAuthenticationForm
from django.contrib.auth.forms import PasswordChangeForm as BasePasswordChangeForm
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.forms import SetPasswordForm as BaseSetPasswordForm
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from users.models import User
from users.models.role import UserRoleChoices
from users.utils import send_email


class send_invitation(Thread):
    def __init__(self, user, current_site):
        self.user = user
        self.current_site = current_site
        Thread.__init__(self)

    def run(self):
        user_mail = self.user.email
        users = PasswordResetForm.get_users(self, user_mail)
        user_name = User.objects.get(email__iexact=user_mail)
        context = {"user_name": user_name.user_name}
        send_email(
            self, users, context, email=self.user.email, current_site=self.current_site
        )
        PasswordResetForm.send_mail(
            self,
            "registration/set_password_subject.txt",
            "registration/set_password_email.html",
            context,
            settings.FROM_EMAIL_ADDRESS,
            self.user.email,
            html_email_template_name="registration/set_password_email.html",
        )
        self.user.save()


class AuthenticationForm(BaseAuthenticationForm):
    error_messages = {
        "inactive": _(
            "Your account is in the process of being verified or your account has been deleted. If you have any question, please contact us using this email: amit@bochan-ltd.co.il"
        ),
        "invalid_login": _("Please enter a correct %(username)s and password."),
        "denied_permission": _(
            "You are group manager the job management web app is not for you"
        ),
    }

    def clean(self):
        username = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")

        if username is not None and password:
            self.user_cache = authenticate(
                self.request, username=username.lower(), password=password
            )

            login_user = User.all_objects.filter(email__iexact=username.lower()).first()
            if login_user:
                if self.user_cache is None and login_user.is_active == True:
                    raise self.get_invalid_login_error()
                else:
                    self.confirm_login_allowed(self.user_cache, login_user)
            else:
                if self.user_cache is None:
                    raise self.get_invalid_login_error()

        return self.cleaned_data

    def confirm_login_allowed(self, user, login_user):
        if login_user.is_active == False:
            raise ValidationError(
                self.error_messages["inactive"],
                code="inactive",
            )
        if user and user.role.title == UserRoleChoices.GROUP_MANAGER.value:
            raise ValidationError(
                self.error_messages["denied_permission"],
                code="denied_permission",
            )


class SetPasswordForm(BaseSetPasswordForm):
    def clean(self):
        cleaned_data = super().clean()
        new_password1 = cleaned_data.get("new_password1")

        if not re.findall("\d", new_password1):
            self.add_error(
                "new_password1", _("The password must contain at least one digit, 0-9.")
            )

        if not re.findall("[A-Z]", new_password1):
            self.add_error(
                "new_password1",
                _("The password must contain at least 1 uppercase letter, A-Z."),
            )

        if not re.findall("[a-z]", new_password1):
            self.add_error(
                "new_password1",
                _("The password must contain at least 1 lowercase letter, a-z."),
            )

        if not re.findall("[~!@#$%^&*_]", new_password1):
            self.add_error(
                "new_password1",
                _("The password must contain at least 1 symbol: ~!@#$%^&*_"),
            )

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit)
        user.is_active = True
        user.save()
        return user


class PasswordChangeForm(BasePasswordChangeForm, SetPasswordForm):
    def __init__(self, user, *args, **kwargs):
        BasePasswordChangeForm.__init__(self, user, *args, **kwargs)
        SetPasswordForm.__init__(self, user, *args, **kwargs)


class UserCreateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["profile_image", "user_name", "email", "phone", "role", "permissions"]


class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["profile_image", "user_name", "email", "phone", "role", "permissions"]


class UserProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["profile_image", "user_name", "email", "phone"]


class EmailValidationOnForgotPassword(PasswordResetForm):
    def clean_email(self):
        email = self.cleaned_data["email"]
        if (
            not User.objects.exclude(is_deleted=True)
            .filter(email__iexact=email)
            .exists()
        ):
            raise ValidationError(
                _("There is no user registered with the specified email address!")
            )
        return email
