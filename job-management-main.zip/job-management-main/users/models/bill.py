from django.db import models
from django.utils.translation import gettext_lazy as _
from users.utils import get_bill_image_path
from users.utils import validate_file_size


class BillType(models.TextChoices):
    MATERIAL = "Material", "Material"
    SIGN = "Sign", "Sign"

from job.base_model_utils import BaseModel
class TypeCounting(models.TextChoices):
    METERS = "מטרים", _("Meters")
    UNITS = "יחידות", _("Units")
    SQM = "מ'ר", _("SQM")
    TONS = "טון", _("Tons")


class Bill(BaseModel):
    # # error_messages={"unique": "This Bill name is already excited"}
    name = models.CharField(
        _("Bill Name"),
        max_length=255,
        unique=True,
        error_messages={"unique": "כבר קיים סעיף עם שם זה"},
        db_index=True
    )
    type_counting = models.CharField(
        _("Type Counting"), choices=TypeCounting.choices, max_length=255
    )
    jumping_ration = models.FloatField(_("Jumping Ration"), blank=True, null=True)
    image = models.ImageField(
        _("Image"),
        upload_to=get_bill_image_path,
        validators=[validate_file_size],
        blank=True,
        null=True,
    )
    type = models.CharField(_("Bill Type"), max_length=50, choices=BillType.choices)
    measurement = models.FloatField(_("Measurement"), blank=True, null=True)
    is_close_time_created = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "bill"
        verbose_name = "bill"
        verbose_name_plural = "bills"
