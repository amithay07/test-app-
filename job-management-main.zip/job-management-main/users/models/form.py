from django.db import models
from django.utils.translation import gettext_lazy as _

from job.base_model_utils import BaseModel
from users.models.bill import Bill


class Form(BaseModel):
    # # error_messages={"unique": "This form name is already excited"}
    name = models.CharField(
        _("Form Name"),
        max_length=255,
        unique=True,
        error_messages={"unique": "קיים טופס עם שם זה"},
        db_index=True
    )
    bill = models.ManyToManyField(
        Bill, verbose_name="Bills", related_name="form_bills", blank=True
    )
    is_sign = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "bill_form"
        verbose_name = "form"
        verbose_name_plural = "forms"
