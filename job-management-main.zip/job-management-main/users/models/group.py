from django.db import models
from django.utils.translation import gettext_lazy as _

from job.base_model_utils import BaseModel
from users.models.form import Form
from users.models.user import User
from users.utils import get_group_image_path
from users.utils import validate_file_size


class Group(BaseModel):
    # error_messages={"unique": "This group name is already excited"}
    name = models.CharField(
        _("group name"),
        max_length=255,
        unique=True,
        error_messages={"unique": "קיימת קבוצה עם שם זה"},
        db_index=True
    )
    member = models.ManyToManyField(
        User, verbose_name=("members"), related_name="group_member"
    )
    form = models.ManyToManyField(
        Form, verbose_name=("Forms"), related_name="group_forms"
    )
    image = models.ImageField(
        _("Group Image"),
        upload_to=get_group_image_path,
        validators=[validate_file_size],
    )
    is_archive = models.BooleanField(default=False, db_index=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "group"
        verbose_name = "group"
        verbose_name_plural = "groups"
        ordering = ["-created_at"]
