import json

from django.core.validators import FileExtensionValidator
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from job.base_model_utils import BaseModel
from users.models.bill import Bill
from users.models.bill import BillType
from users.models.bill import TypeCounting
from users.models.form import Form
from users.models.group import Group
from users.models.user import User
from users.utils import get_closejobbill_path
from users.utils import get_job_attachment_path
from users.utils import get_job_image_path
from users.utils import validate_file_size


class JobStatus(models.TextChoices):
    OPEN = "פתוח", _("Open")
    CLOSE = "סגור", _("Close")
    RETURN = "לַחֲזוֹר", _("Return")
    TRANSFER = "הועברה", _("Transfer")
    PARTIAL = "חלקי", _("Partial")
    WRONG_INFORMATION = "מידע שגוי", _("Wrong_information")
    DUPLICATE = "לְשַׁכְפֵּל", _("Duplicate")


class Job(BaseModel):
    # error_messages={"unique": "A job already exists with this job ID"}
    job_id = models.CharField(
        _("job_id"),
        unique=True,
        blank=True,
        null=True,
        max_length=255,
        error_messages={"unique": "כבר קיימת משימה עם מזהה זה"},
        db_index=True,
    )
    address = models.CharField(_("address"), max_length=255)
    address_information = models.TextField(
        _("address information"), blank=True, null=True
    )
    description = models.CharField(_("job description"), max_length=255)
    latitude = models.DecimalField(
        _("latitude"), max_digits=20, decimal_places=16, blank=True, null=True
    )
    longitude = models.DecimalField(
        _("longitude"), max_digits=20, decimal_places=16, blank=True, null=True
    )
    priority = models.BooleanField(_("priority"), default=False)
    further_inspection = models.BooleanField(_("further_inspection"), default=False)
    is_lock_closed = models.BooleanField(default=False)
    further_billing = models.BooleanField(_("further_billing"), default=False)
    form = models.ManyToManyField(
        Form, verbose_name="form", related_name="job_forms", blank=True
    )
    bill = models.ManyToManyField(
        Bill, verbose_name="bills", related_name="job_bills", blank=True
    )
    closed_at = models.DateTimeField(blank=True, null=True)
    closed_by = models.ForeignKey(
        User,
        verbose_name="job closed by",
        related_name="job_closed_by",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
    )
    notes = models.CharField(_("notes"), max_length=255, blank=True, null=True)
    status = models.CharField(
        _("job status"), max_length=255, choices=JobStatus.choices, db_index=True
    )
    comment = models.TextField(_("comment"), blank=True, null=True)
    duplicate_reference = models.TextField(
        _("duplicate_reference"), blank=True, null=True
    )

    def generate_job_id(self):
        current_date = timezone.now().strftime("%d%m%Y")
        latest_job = (
            Job.objects.filter(job_id__startswith=current_date).order_by("-id").first()
        )
        if latest_job:
            last_id_numeric = int(latest_job.job_id[len(current_date) + 1 :])
            new_id_numeric = last_id_numeric + 1
        else:
            new_id_numeric = 1
        new_job_id = f"{current_date}.{new_id_numeric}"
        return new_job_id

    def set_duplicate_reference(self, value):
        if not self.duplicate_reference:
            self.duplicate_reference = value
        else:
            self.duplicate_reference += value

    def get_duplicate_reference(self):
        if self.duplicate_reference:
            return self.duplicate_reference
        return ""

    def save(self, *args, **kwargs):
        if not self.job_id:
            self.job_id = self.generate_job_id()
        super().save(*args, **kwargs)

    class Meta:
        db_table = "job"
        verbose_name = "job"
        verbose_name_plural = "jobs"


class JobNote(BaseModel):
    job = models.ForeignKey(
        Job,
        verbose_name=("Job Notes"),
        related_name="job_notes",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
    )
    note = models.CharField(_("notes"), max_length=255, blank=True, null=True)

    class Meta:
        db_table = "job_note"
        verbose_name = "job_note"
        verbose_name_plural = "job_notes"


class TransferJob(BaseModel):
    group = models.ForeignKey(
        Group, verbose_name=("group_id"), on_delete=models.CASCADE
    )
    job = models.ForeignKey(
        Job,
        verbose_name=("Assign jobs"),
        related_name="assign_job",
        on_delete=models.CASCADE,
        blank=True,
    )
    status = models.CharField(
        _("job status"), max_length=255, choices=JobStatus.choices, null=True
    )
    further_inspection = models.BooleanField(_("further_inspection"), default=False)
    further_billing = models.BooleanField(_("further_billing"), default=False)
    is_parent_group = models.BooleanField(default=False)
    is_lock_closed = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False, db_index=True)
    is_reviewed = models.BooleanField(default=False)

    class Meta:
        db_table = "transfer_job"
        verbose_name = "transfer_job"
        verbose_name_plural = "transfer_jobs"
        unique_together = ("group", "job")
        indexes = [
            models.Index(
                fields=["is_active", "group_id"], name="idx_transferjob_active_group"
            ),
        ]


class JobImage(BaseModel):
    job = models.ForeignKey(Job, related_name="job_image", on_delete=models.CASCADE)
    close_job_image = models.BooleanField(default=False)
    image = models.FileField(
        upload_to=get_job_image_path,
        verbose_name="job images",
        validators=[
            FileExtensionValidator(
                allowed_extensions=["jpg", "jpeg", "png", "mov", "mp4"]
            ),
            validate_file_size,
        ],
    )

    class Meta:
        db_table = "job_image"
        verbose_name = "job_image"
        verbose_name_plural = "job_images"
        indexes = [
            models.Index(fields=["job_id"], name="idx_jobimage_job"),
        ]


class JobAttachment(BaseModel):
    job = models.ForeignKey(
        Job, related_name="job_attachment", on_delete=models.CASCADE
    )
    close_job_attachment = models.BooleanField(default=False)
    attachment = models.FileField(
        upload_to=get_job_attachment_path,
        verbose_name="job attachment",
        validators=[
            FileExtensionValidator(
                allowed_extensions=[
                    "pdf",
                    "xls",
                    "xlsx",
                    "doc",
                    "ppt",
                    "pptx",
                    "docx",
                    "csv",
                    "mp3",
                    "m4a",
                    "txt",
                ]
            ),
            validate_file_size,
        ],
    )

    def __unicode__(self):
        return self.attachment

    class Meta:
        db_table = "job_attachment"
        verbose_name = "job_attachment"
        verbose_name_plural = "job_attachments"


class ReturnJob(BaseModel):
    job = models.ForeignKey(
        TransferJob, related_name="return_job_id", on_delete=models.CASCADE
    )
    status = models.CharField(
        _("job status"), max_length=255, choices=JobStatus.choices, db_index=True
    )
    duplicate = models.ForeignKey(
        TransferJob,
        related_name="related_job_id",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    comment = models.TextField(_("comment"), blank=True, null=True)
    return_to = models.ManyToManyField(
        User, verbose_name="returns_to", related_name="return_to_user_list"
    )
    group = models.ForeignKey(
        Group,
        verbose_name="return_group",
        related_name="returned_job_group",
        on_delete=models.CASCADE,
        null=True,
    )
    notes = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "return_job"
        verbose_name = "retrun_job"
        verbose_name_plural = "retrun_jobs"


class RecentSearchJob(BaseModel):
    job = models.ForeignKey(
        TransferJob,
        related_name="related_job",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    class Meta:
        db_table = "recent_search_job"
        verbose_name = "recent_search_job"
        verbose_name_plural = "recent_search_jobs"


class JobBill(BaseModel):
    job = models.ForeignKey(
        TransferJob, related_name="job_bills", on_delete=models.CASCADE
    )
    form = models.ManyToManyField(Form, related_name="job_assign_forms")
    bill = models.ManyToManyField(Bill, related_name="job_assign_bills")


class CloseJobBill(BaseModel):
    job = models.ForeignKey(
        TransferJob, related_name="close_job_id", on_delete=models.CASCADE
    )
    name = models.CharField(
        _("Bill Name"),
        max_length=255,
    )
    type_counting = models.CharField(
        _("Type Counting"), choices=TypeCounting.choices, max_length=255
    )
    jumping_ration = models.FloatField(_("Jumping Ration"), blank=True, null=True)
    image = models.ImageField(
        _("Image"),
        upload_to=get_closejobbill_path,
        blank=True,
        null=True,
    )
    type = models.CharField(_("Bill Type"), max_length=50, choices=BillType.choices)
    measurement = models.FloatField(_("Measurement"), blank=True, null=True)
    is_created = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "close_job_bill"
        verbose_name = "close_job_bills"
        verbose_name_plural = "close_job_bills"
        indexes = [
            models.Index(fields=["job_id"], name="idx_closejobbill_job"),
        ]


class JobLog(models.Model):
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="job_logs")
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_jobs",
    )
    updated_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="updated_jobs",
    )
    transferred_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="transferred_jobs",
    )
    returned_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="returned_jobs",
    )
    closed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="closed_jobs",
    )
    partially_closed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="partially_closed_jobs",
    )
    created_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50, null=True, blank=True)

    class Meta:
        verbose_name = "Job Log"
        verbose_name_plural = "Job Logs"

    def __str__(self):
        return f"Job Log - {self.job}"
