from django.db import models

from job.base_model_utils import BaseModel
from users.models.group import Group
from users.models.job import TransferJob
from users.models.user import User


class Notification(BaseModel):
    job = models.ForeignKey(
        TransferJob,
        related_name="job_notification_id",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    sender = models.ForeignKey(
        User, related_name="notification_sender_id", on_delete=models.CASCADE
    )
    receiver = models.ForeignKey(
        User, related_name="notification_receiver_id", on_delete=models.CASCADE
    )
    message = models.TextField(max_length=255, null=True, blank=True)
    notification_type = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        db_table = "notification"


class ChatNotification(BaseModel):
    group = models.ForeignKey(
        Group,
        related_name="Chat_notification_id",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    sender = models.ForeignKey(
        User, related_name="chat_notification_sender_id", on_delete=models.CASCADE
    )
    receiver = models.ForeignKey(
        User, related_name="chat_notification_receiver_id", on_delete=models.CASCADE
    )
    message = models.TextField(null=True, blank=True)
    attachment = models.TextField(null=True, blank=True)
    notification_type = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        db_table = "chat_notification"
