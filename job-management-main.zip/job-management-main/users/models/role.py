from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _


class UserRoleChoices(models.TextChoices):
    ADMIN = "מנהל מערכת", _("Admin")
    GROUP_MANAGER = "מנהל קבוצה", _("Group Manager")
    INSPECTOR = "מְפַקֵחַ", _("Inspector")
    USER = "מִשׁתַמֵשׁ", _("User")


class UserRole(models.Model):
    title = models.CharField(
        _("User Role"),
        max_length=255,
        unique=True,
        choices=UserRoleChoices.choices,
        db_index=True
    )

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("roles")
