from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
from phonenumber_field.modelfields import PhoneNumberField

from users.models.manager import AllUserManager
from users.models.manager import UserManager
from users.models.role import UserRole
from users.utils import get_user_image_path
from users.utils import validate_file_size


def validate_unique_email(value):
    if User.objects.filter(email=value).exists():
        raise ValidationError("אימייל זה כבר קיים")


class User(AbstractUser):
    username = None
    profile_image = models.ImageField(
        upload_to=get_user_image_path,
        validators=[validate_file_size],
        blank=True,
        null=True,
        verbose_name="Profile Image",
    )
    # error_messages={"unique": "This username is already excited"}
    user_name = models.CharField(
        _("User Name"),
        max_length=255,
        unique=True,
        null=True,
        blank=False,
        error_messages={"unique": "שם משתמש זה כבר קיים"},
        db_index=True
    )
    # error_messages={"unique": "This email already exists"}
    email = models.EmailField(
        _("Email"),
        max_length=255,
        unique=True,
        null=True,
        blank=False,
        # validators=[validate_unique_email],
        error_messages={"unique": "אימייל זה כבר קיים"},
        db_index=True
    )
    phone = PhoneNumberField(
        _("Phone No."),
        help_text="Provide a number with country code (e.g. +12125552368).",
        null=True,
        blank=False,
    )
    role = models.ForeignKey(
        UserRole,
        on_delete=models.PROTECT,
        null=True,
        blank=False,
        verbose_name="User Role",
        db_index=True,
    )
    permissions = models.ManyToManyField(
        "Group", verbose_name=("groups"), related_name="groups", blank=True
    )
    all_permissions = models.BooleanField(default=False)

    is_staff = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    restrict_login_before = models.DateTimeField(blank=True, null=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects = UserManager()
    all_objects = AllUserManager()

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"

    def get_absolute_url(self):
        return reverse("users:users")

    def save(self, *args, **kwargs):
        if self.email:
            self.email = self.email.lower()
        super().save(*args, **kwargs)


class TempUser(models.Model):
    # error_messages={"unique": "This username is already excited"}
    user_name = models.CharField(
        _("User Name"),
        max_length=255,
        unique=True,
        null=True,
        blank=False,
        error_messages={"unique": "שם משתמש זה כבר קיים"},
        db_index=True
    )
    # error_messages={"unique": "This email already exists"}
    email = models.EmailField(
        _("Email"),
        max_length=255,
        unique=True,
        null=True,
        blank=False,
        error_messages={"unique": "אימייל זה כבר קיים"},
        db_index=True
    )
    phone = PhoneNumberField(
        _("Phone No."),
        help_text="Provide a number with country code (e.g. +12125552368).",
        null=True,
        blank=False,
    )
    password = models.CharField(max_length=15)

    class Meta:
        verbose_name = "TempUser"
        verbose_name_plural = "TempUser"
