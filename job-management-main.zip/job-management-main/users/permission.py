from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from rest_framework.permissions import BasePermission
from rest_framework_roles.roles import is_anon
from rest_framework_roles.roles import is_user

from users.models.role import UserRoleChoices


class UserPermission(BasePermission):
    def has_permission(self, request, view):
        if not request.user.is_anonymous:
            return bool(
                str(request.user.role) == str(UserRoleChoices.ADMIN.value)
                and request.user.is_authenticated
            )


class IsInspector(BasePermission):
    def has_permission(self, request, view):
        if not request.user.is_anonymous:
            return bool(
                str(request.user.role) == str(UserRoleChoices.INSPECTOR.value)
                and request.user.is_authenticated
            )


class IsGroupManager(BasePermission):
    def has_permission(self, request, view):
        if not request.user.is_anonymous:
            return bool(
                str(request.user.role) == str(UserRoleChoices.GROUP_MANAGER.value)
                and request.user.is_authenticated
            )


class IsSuperUser(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_superuser)


def is_inspector(request, view):
    return bool(
        is_user(request, view)
        and request.user.role.title == UserRoleChoices.INSPECTOR.value
    )


def is_group_manager(request, view):
    return bool(
        is_user(request, view)
        and request.user.role.title == UserRoleChoices.GROUP_MANAGER.value
    )


def is_admin(request, view):
    return bool(
        is_user(request, view)
        and request.user.role.title == UserRoleChoices.ADMIN.value
    )


def is_simple_user(request, view):
    return bool(
        is_user(request, view) and request.user.role.title == UserRoleChoices.USER.value
    )


def is_superuser(request, view):
    return bool(is_user(request, view) and request.user.is_superuser)


ROLES = {
    "admin": is_admin,
    "simple_user": is_simple_user,
    "user": is_user,
    "anon": is_anon,
    "inspector": is_inspector,
    "group_manger": is_group_manager,
    "is_superuser": is_superuser,
}


@method_decorator(login_required, name="dispatch")
class OnlyForAdmin:
    def dispatch(self, request, *args, **kwargs):
        if not request.user.role.title == UserRoleChoices.ADMIN.value:
            return redirect(reverse_lazy("index"))
        return super().dispatch(request, *args, **kwargs)


class CheckPermission(BasePermission):
    """
    Permission class to check if the user has the required group permission.
    """

    def has_permission(self, request, view):
        """
        Check if the user has the required group permission.
        """
        action = request.method.lower()
        permissions = view.view_permissions.get(action)
        user = request.user
        if user.is_authenticated:
            if user.role.title == "מנהל קבוצה":
                permission = "group_manger"
            elif user.role.title == "מְפַקֵחַ":
                permission = "inspector"
            elif user.role.title == "מנהל מערכת":
                permission = "admin"
            elif user.role.title == "מִשׁתַמֵשׁ":
                permission = "simple_user"
            elif user.is_superuser:
                permission = "is_superuser"
            else:
                return False
            if permissions.get(permission):
                return True
        return False
