import datetime

from django import template
from django.utils.timesince import timesince
from django.utils.translation import gettext_lazy as _

register = template.Library()


@register.filter(name="addclass")
def addclass(value, arg):
    return value.as_widget(attrs={"class": arg})


@register.filter("startswith")
def startswith(text, starts):
    return text.startswith(starts)


@register.filter(name="split")
def split(value, arg):
    return value.split(arg)


image_formats = [
    "png",
    "jpg",
    "jpeg",
]
video_formats = [
    "mp4",
    "mkv",
    "m4a",
    "mov",
    "wmv",
    "avi",
    "avchd",
    "flv",
    "f4v",
    "swf",
    "webm",
    "mpeg-2",
    "html5",
]


@register.filter(name="check_extension")
def check_extension(values):
    if values.split(".")[-1] in image_formats:
        return "Image"
    elif values.split(".")[-1] in video_formats:
        return "Video"
    else:
        return "Document"


@register.filter(name="media_list")
def media_list(values):
    if values:
        images = values.job_image.all()
        media = {}
        for img_video in images:
            image_status = (
                _("Before") if img_video.close_job_image != True else _("After")
            )
            if str(img_video.image).split(".").pop() in video_formats:
                media[img_video.image.url] = image_status
            if str(img_video.image).split(".").pop() in image_formats:
                media[img_video.image.url] = image_status
        return media


@register.filter(name="video_list")
def video_list(value):
    bool_value = True if value in video_formats else False
    return bool_value


@register.filter(name="custom_timesince")
def custom_timesince(value):
    if isinstance(value, str):
        value = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")

    time_since = timesince(value).strip().split(",")[0]
    short_timesince = (
        time_since.replace("minutes", "m")
        .replace("minute", "m")
        .replace("hours", "h")
        .replace("hour", "h")
        .replace("days", "d")
        .replace("day", "d")
        .replace("weeks", "w")
        .replace("week", "w")
        .replace("months", "m")
        .replace("month", "m")
        .replace("years", "y")
        .replace("year", "y")
    )
    return short_timesince


@register.filter(name="group_images")
def group_images(images):
    grouped_images = [images[i : i + 2] for i in range(0, len(images), 2)]
    return grouped_images


@register.filter(name="split_by_dot")
def split_by_dot(value):
    return value.split(".")


@register.filter(name="get_first_image")
def get_first_image(value):
    if value:
        images = value.job_image.all()
        media = ""
        for img in images:
            if str(img.image).split(".").pop() in image_formats:
                media = img.image.url
                break
        return media
