from django.urls import path

from users.views import CreateUserView
from users.views import UpdateUserView
from users.views import UserDeactiveView
from users.views import UserListView

app_name = "users"
urlpatterns = [
    path("", UserListView.as_view(), name="user-list"),
    path("add/", CreateUserView.as_view(), name="add-user"),
    path("update-user/<int:pk>/", UpdateUserView.as_view(), name="update-user"),
    path("delete-user/<int:pk>/", UserDeactiveView.as_view(), name="delete-user"),
]
