from django.conf import settings
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.views import PasswordChangeView
from django.contrib.auth.views import PasswordResetView
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import BadHeaderError
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.urls import reverse
from django.urls import reverse_lazy
from django.utils import translation
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views.generic import CreateView
from django.views.generic import ListView
from django.views.generic import RedirectView
from django.views.generic import UpdateView

from jobs.views import NotificationList
from users.forms import EmailValidationOnForgotPassword
from users.forms import PasswordChangeForm
from users.forms import UserCreateForm
from users.forms import UserProfileForm
from users.forms import UserUpdateForm
from users.forms import send_invitation
from users.models import Group
from users.models import User
from users.models import UserRole
from users.models.group import Group
from users.models.role import UserRoleChoices
from users.permission import OnlyForAdmin
from users.utils import send_email


class ResetPasswordView(PasswordResetView):
    form_class = EmailValidationOnForgotPassword
    template_name = "registration/forgot-password.html"
    subject_template_name = "registration/reset_password_subject.txt"
    html_email_template_name = "registration/email.html"
    email_template_name = "registration/email.html"
    success_url = "registration/password_reset.html"

    def post(self, request, *args, **kwargs):
        user_mail = request.POST.get("email", None)
        form = self.form_class(data=self.request.POST)
        if form.is_valid():
            users = PasswordResetForm.get_users(self, user_mail)
            user_name = User.objects.get(email__iexact=user_mail)
            context = {"user_name": user_name.user_name}
            current_site = get_current_site(self.request)
            send_email(self, users, context, email=user_mail, current_site=current_site)
            try:
                if not context:
                    return JsonResponse({"send_mail_failed": _("User is Inactive")})
                # language translation in sending mail doesn't work
                lang_code = request.LANGUAGE_CODE
                with translation.override(lang_code):
                    PasswordResetForm.send_mail(
                        self,
                        self.subject_template_name,
                        self.email_template_name,
                        context,
                        settings.FROM_EMAIL_ADDRESS,
                        user_mail,
                        self.html_email_template_name,
                    )
            except BadHeaderError:
                return JsonResponse(
                    {"send_mail_failed": _("Invalid header found or Send Email Failed")}
                )
            return JsonResponse({"send_mail_successfully": "successfully"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class ChangePasswordView(PasswordChangeView):
    template_name = "registration/change_password.html"
    form_class = PasswordChangeForm
    success_url = reverse_lazy("login")

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.user, data=self.request.POST)
        if form.is_valid():
            super(ChangePasswordView, self).post(request, *args, **kwargs)
            user = form.save()
            update_session_auth_hash(request, user)
            return JsonResponse({"password_change_status": "success"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class UserListView(ListView, OnlyForAdmin):
    model = User
    template_name = "user-list.html"
    success_url = reverse_lazy("users:user-list")
    ordering = ["-id"]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        selected_role = self.request.GET.get("role-filter")
        page_number = self.request.GET.get("page")

        paginator = Paginator(self.get_queryset(), 10)
        context["paginator"] = paginator
        context["user_list"] = paginator.get_page(page_number)
        try:
            context["page_range"] = paginator.page(page_number)
        except PageNotAnInteger:
            context["page_range"] = paginator.page(1)
        except EmptyPage:
            context["page_range"] = paginator.page(paginator.num_pages)

        context["roles"] = list(UserRole.objects.all())
        context["permissions"] = list(Group.objects.all())
        context["selected_role"] = selected_role
        context["notification"] = NotificationList(self)
        return context

    def get_queryset(self):
        search = self.request.GET.get("search")
        current_user = self.request.user
        if current_user.is_superuser:
            queryset = (
                User.all_objects.exclude(email__iexact=current_user.email)
                .order_by("-date_joined")
                .select_related("role")
            )
        else:
            queryset = (
                User.objects.exclude(email__iexact=current_user.email)
                .order_by("-date_joined")
                .select_related("role")
            )
        selected_role = self.request.GET.get("role-filter")
        if selected_role:
            queryset = queryset.filter(role__title=selected_role)
        if search:
            return queryset.filter(user_name__icontains=search)
        return queryset


@method_decorator(login_required, name="dispatch")
class UserProfileView(UpdateView):
    form_class = UserProfileForm
    template_name = "user_profile.html"
    success_url = reverse_lazy("users:user-list")

    def get_object(self):
        return self.request.user

    def get(self, request, *args, **kwargs):
        user_data = list(
            User.objects.exclude(is_deleted=True).filter(id=request.user.id).values()
        )
        return JsonResponse({"form": user_data})

    def post(self, request, *args, **kwargs):
        data = self.request.POST.dict()
        data["phone"] = "+972" + str(data["phone"])
        form = self.form_class(
            instance=self.request.user, data=data, files=self.request.FILES
        )
        if form.is_valid():
            form.save()
            return JsonResponse({"user_profile_status": "success"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class CreateUserView(CreateView, OnlyForAdmin):
    model = User
    form_class = UserCreateForm
    template_name = "user-list.html"
    success_url = reverse_lazy("users:user-list")

    def post(self, request, *args, **kwargs):
        data = {
            key: request.POST.getlist(key) if key == "permissions" else value
            for key, value in request.POST.items()
        }

        data["phone"] = "+972" + str(data["phone"])
        permissions = data.get("permissions")

        all_permissions = (
            False
            if not permissions
            else True
            if (permissions.pop(0) if "all_permissions" in permissions else False)
            else False
        )
        form = self.form_class(data, self.request.FILES)
        if form.is_valid():
            user = form.save()
            current_site = get_current_site(self.request)
            send_email_invitation = send_invitation(user, current_site)
            send_email_invitation.start()

            # on selecting all_permissions , add that user as member in all groups
            if all_permissions:
                user.permissions.add(*list(Group.objects.all()))
                GroupUserRelation = Group.member.through
                GroupUserRelation.objects.bulk_create(
                    [
                        GroupUserRelation(user_id=user.id, group_id=group.id)
                        for group in Group.objects.iterator()
                    ]
                )
            else:
                if permissions:
                    groups = Group.objects.filter(id__in=permissions)
                    for group in groups:
                        group.member.add(user)

            return JsonResponse({"create_user_status": "success"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class UpdateUserView(UpdateView):
    model = User
    form_class = UserUpdateForm
    template_name = None
    success_url = reverse_lazy("users:user-list")
    queryset = User.objects.exclude(is_deleted=True)

    def get(self, request, *args, **kwargs):
        pk = kwargs.get("pk")
        instance = self.model.all_objects.filter(id=pk)
        response = list(self.model.all_objects.filter(id=pk).values())
        permissions = list(
            getattr(instance.first(), "permissions").values_list("id", flat=True)
        )

        return JsonResponse({"data": response, "permissions": permissions})

    def post(self, request, *args, **kwargs):
        user = get_object_or_404(User, id=kwargs.get("pk"))
        id = user.id

        data = self.request.POST.dict()
        data["phone"] = "+972" + str(data["phone"])
        data["permissions"] = request.POST.getlist("permissions")

        form = self.form_class(instance=user, data=data, files=self.request.FILES)
        groups_id = request.POST.getlist("permissions")
        groups = Group.objects.filter(id__in=groups_id)

        if (
            str(user.role.id) != self.request.POST.get("role")
            and str(user.role) == UserRoleChoices.ADMIN.value
        ):
            groups_list = Group.objects.filter(member=id)
            group_names = ""
            for group in groups_list:
                managers_list = (
                    group.member.filter(role__title=user.role)
                    .exclude(id=User.objects.filter(is_superuser=True).first().id)
                    .values_list("id", flat=True)
                )
                if len(managers_list) == 1 and id in managers_list:
                    group_names += group.name + ", "
            if group_names:
                # The user {user.user_name} is only {user.role} in {group_names} before deactivate the user {user.user_name}
                # please replace that user with another one than you can change the role of user
                form.add_error(
                    "role",
                    f"המשתמש {user.user_name} הוא רק {user.role} ב-{group_names} לפני השבתת המשתמש {user.user_name}, אנא החלף את המשתמש הזה במשתמש אחר מאשר תוכל לשנות את תפקיד המשתמש",
                )
                return JsonResponse({"error": form.errors if form.errors else None})

        # Remove user form group member
        for group in Group.objects.all():
            group.member.remove(user)

        if form.is_valid():
            form.save()

            # Add user in group member
            for group in groups:
                group.member.add(user)
            return JsonResponse({"update_user_status": "success"})
        return JsonResponse({"error": form.errors if form.errors else None})


@method_decorator(login_required, name="dispatch")
class UserDeactiveView(OnlyForAdmin, UpdateView):
    model = User
    template_name = "user_deactive.html"
    success_url = reverse_lazy("users:user-list")
    queryset = User.objects.exclude(is_deleted=True)

    def post(self, request, *args, **kwargs):
        id = kwargs["pk"]
        user_role = User.objects.get(id=id)

        groups_list = Group.objects.filter(member=id)
        group_names = ""

        # Give permission to deactivate if same role of requested user is available in group.
        for group in groups_list:
            managers_list = (
                group.member.filter(role__title=user_role.role)
                .exclude(is_superuser=True)
                .values_list("id", flat=True)
            )
            if len(managers_list) == 1 and id in managers_list:
                group_names += group.name + ", "

        if group_names:
            return JsonResponse({"error": f"{group_names}"})
        else:
            user_role.is_active = False
            user_role.is_deleted = True
            user_role.save()
            return JsonResponse({"delete_user_status": "success"})


@method_decorator(login_required, name="dispatch")
class ResendInvitationView(RedirectView):
    def get_redirect_url(self, pk, *args, **kwargs):
        user = User.all_objects.get(pk=pk)
        current_site = get_current_site(self.request)
        send_email_invitation = send_invitation(user, current_site)
        send_email_invitation.start()
        redirect_url = self.request.build_absolute_uri(
            reverse("users:user-list", args=args)
        )
        return redirect_url
