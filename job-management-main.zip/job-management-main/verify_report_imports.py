#!/usr/bin/env python
"""
Verification script to check all imports are correct in jobs/apis/views.py
"""

import sys
import os

# Add project root to path
sys.path.insert(0, '/home/ubuntu/job-management')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'job.settings')

import django
django.setup()

print("✓ Django setup successful")

# Test imports
try:
    from collections import defaultdict
    print("✓ defaultdict imported")
except ImportError as e:
    print(f"✗ Failed to import defaultdict: {e}")
    sys.exit(1)

try:
    from django.db.models import Prefetch
    print("✓ Prefetch imported")
except ImportError as e:
    print(f"✗ Failed to import Prefetch: {e}")
    sys.exit(1)

try:
    from users.models.job import JobImage, CloseJobBill, TransferJob
    print("✓ JobImage, CloseJobBill, TransferJob imported")
except ImportError as e:
    print(f"✗ Failed to import models: {e}")
    sys.exit(1)

# Test that the views can be imported
try:
    from jobs.apis.views import PdfGeneratorView, MultiplePdfGeneratorView
    print("✓ PdfGeneratorView imported")
    print("✓ MultiplePdfGeneratorView imported")
except ImportError as e:
    print(f"✗ Failed to import views: {e}")
    sys.exit(1)

# Verify Prefetch is used correctly in queryset
try:
    queryset = PdfGeneratorView.queryset
    print(f"✓ PdfGeneratorView queryset defined: {queryset.query.__class__.__name__}")
except Exception as e:
    print(f"✗ Failed to access PdfGeneratorView queryset: {e}")
    sys.exit(1)

print("\n" + "="*50)
print("All imports and views verified successfully! ✓")
print("="*50)
